package com.genesis.core.domain.plan.controller;

import java.util.List;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.genesis.core.domain.plan.model.PlanModel;
import com.genesis.core.domain.plan.model.PlanSourceModel;
import com.genesis.core.domain.plan.service.PlanSourceService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/planSource")
@Tag(name = "Plan Source")
public class PlanSourceController {
	
	private final PlanSourceService planSourceSvcService;

	@Operation(summary = "Get Plan Sources", description = "Get a list of Plan sources")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Found the Plan", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = PlanModel.class)) }),
			@ApiResponse(responseCode = "404", description = "Plans not found", content = @Content) })
	@GetMapping
	public List<PlanSourceModel> PlanSource() throws InterruptedException {
		return planSourceSvcService.getPlanSources();
	}

	@Operation(summary = "Get Plan source by given Id")
	@GetMapping(value = "/{planSourceId}")
	public PlanSourceModel getPlanSource(@PathVariable String planSourceId) throws InterruptedException {
		return planSourceSvcService.getPlanSource(planSourceId);
	}

	@Operation(summary = "Create Plan Source")
	@PostMapping
	public ResponseEntity<PlanSourceModel> addPlanSource(@RequestBody PlanSourceModel planSourceModel) {
		PlanSourceModel newPlanSourceModel= planSourceSvcService.createPlanSource(planSourceModel);
		return ResponseEntity.status(HttpStatus.CREATED).body(newPlanSourceModel);
	}


	@Operation(summary = "Update Plan Source")
	@PutMapping(value = "/{planSourceId}")
	public ResponseEntity<PlanSourceModel> updatePlanSource(@PathVariable String planSourceId,
														 @RequestBody PlanSourceModel planSourceModel) {
		planSourceModel.setId(planSourceId);
		return ResponseEntity.status(HttpStatus.OK)
				.body(planSourceSvcService.updatePlanSource(planSourceModel));
	}
	
	@Operation(summary = "Delete Plan Source")
	@DeleteMapping(value = "/{planSourceId}")
	public ResponseEntity<String> deletePlanSource(@PathVariable String planSourceId) {
		planSourceSvcService.deletePlanSource(planSourceId);
		return ResponseEntity.status(HttpStatus.OK).body("Record is deleted");
	}

}