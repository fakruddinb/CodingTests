package com.genesis.core.domain.plan.model;

import java.io.Serializable;
import java.time.LocalDate;


import com.genesis.core.domain.plan.domain.enums.BankAccountType;
import com.genesis.core.domain.plan.domain.enums.RddTypeCode;

import lombok.Data;

@Data
public class PlanAchModel implements Serializable {
	private static final long serialVersionUID = -4159888723776152727L;
	private String id;
	private	Integer	abaSequanceId;
	private String routingNo;
	private String bankAccountNo;
	private BankAccountType accountType;
	private String bankName;
	private String nickName;
	private LocalDate effectiveDate;
	private String accountStatus;
	private RddTypeCode rddTypeCode;
}
