package com.genesis.core.domain.plan.model;

import java.io.Serializable;


import lombok.Data;

@Data
public class VestingRulesModel implements Serializable {

	private static final long serialVersionUID = -5611634245306331965L;
	private String id;
	private Long vestingSchdId;
	private String vestingSchdTypCd;
	private Long vestingSchdPriorToYear;
	private Integer forfeitureAllocCd;
	private String reportSourceNm;
	private String vestingCompPeriod;
	private String forfAdoptEmpCd;
	private Integer ForfYrsPerCd;
	private Integer reinstYrsOfServCd;
	private String approvalCode;
	private Integer priorServCounted;
	private String rehireTrackCd;
	private String vestingYrOfServCd;
	private String actualEquivCd;
	private Integer vestYearHrsCt;
	private Integer equivVestCd;
	private String equivVestPerCd;
	private Integer roundingMoNo;
	private String servDisregardCd;
	private String servRecognizedCd;
	private String priorPlanInclCd;
	private Integer priorPlanYearsN;
	private String priorPlanT;
	private String eligIndCd;
	private String allocAccrualIndCd;
	private String vestIndCd;
	private String forfDistForTremCd;
	private String forfDistForRetCd;
	private String forfDistForDeathCd;
	private String forfDistFundsCd;
	private String forfDistForDisabCd;
	private Integer applVestTypCd;
	private Integer allocTimingCd;

}
