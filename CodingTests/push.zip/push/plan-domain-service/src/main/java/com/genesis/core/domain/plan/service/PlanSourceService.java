package com.genesis.core.domain.plan.service;

import java.util.List;
import java.util.Optional;


import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.genesis.core.domain.framework.exceptions.ResourceFoundException;
import com.genesis.core.domain.framework.exceptions.ResourceNotFoundException;
import com.genesis.core.domain.framework.utils.MapperUtils;
import com.genesis.core.domain.plan.domain.PlanSource;
import com.genesis.core.domain.plan.model.PlanSourceModel;
import com.genesis.core.domain.plan.repository.PlanSourceRepository;
import com.github.fge.jsonpatch.JsonPatch;
import com.github.fge.jsonpatch.JsonPatchException;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PlanSourceService {


	public final PlanSourceRepository planSourceRepository;
	public final MapperUtils jsonUtils;
	
	public List<PlanSourceModel> getPlanSources() {
		return jsonUtils.mapList((List<PlanSource>) planSourceRepository.findAll(), PlanSourceModel.class);
	}

	public PlanSourceModel getPlanSource(String id) {
		Optional<PlanSource> planSource = planSourceRepository.findById(id);
		if (planSource.isPresent()) {
			return jsonUtils.mapObject(planSource.get(), PlanSourceModel.class);
		} else {
			throw new ResourceNotFoundException("PlanSource is not exists for given id " + id);
		}
	}

	public void deletePlanSource(String id) {

		Optional<PlanSource> planSource = planSourceRepository.findById(id);

		if (planSource.isPresent()) {
			planSourceRepository.deleteById(id);
		} else {
			throw new ResourceNotFoundException("PlanSource is not exists for given id " + id);
		}

	}

	public PlanSourceModel createPlanSource(PlanSourceModel planSourceModel) {

		if (planSourceModel.getId() == null || !planSourceRepository.findById(planSourceModel.getId()).isPresent()) {

			PlanSource planSource = jsonUtils.mapObjectWithUUID(planSourceModel, PlanSource.class);
			planSource = planSourceRepository.save(planSource);
			return jsonUtils.mapObject(planSource, PlanSourceModel.class);
		} else {
			throw new ResourceFoundException("PlanSource is already exists for given id " + planSourceModel.getId());
		}

	}

	public PlanSourceModel updatePlanSource(PlanSourceModel planSourceModel) {
		String planSourceID = planSourceModel.getId();
		Optional<PlanSource> foundPlanSource = planSourceRepository.findById(planSourceID);

		if (foundPlanSource.isPresent()) {
			PlanSource planSource = jsonUtils.mapObject(planSourceModel, PlanSource.class);
			planSource = planSourceRepository.save(planSource);
			return jsonUtils.mapObject(planSource, PlanSourceModel.class);
		} else {
			throw new ResourceNotFoundException("PlanSource is not exists for given id " + planSourceID);
		}

	}

	public PlanSourceModel patchPlanSource(String planSourceId, JsonPatch planSourceModel)
			throws JsonProcessingException, JsonPatchException {
		Optional<PlanSource> currentplanSource = planSourceRepository.findById(planSourceId);
		if (currentplanSource.isPresent()) {
			PlanSource planSource = jsonUtils.applyPatchToModel(planSourceModel, currentplanSource.get(), PlanSource.class);
			planSource = planSourceRepository.save(planSource);
			return jsonUtils.mapObject(planSource, PlanSourceModel.class);
		} else {
			throw new ResourceNotFoundException("PlanSource is not exists for given id " + planSourceId);
		}
	}

}
