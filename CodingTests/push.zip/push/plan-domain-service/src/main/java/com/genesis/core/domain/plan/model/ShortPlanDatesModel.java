package com.genesis.core.domain.plan.model;

import java.io.Serializable;
import java.util.Date;


import lombok.Data;

@Data
public class ShortPlanDatesModel implements Serializable {

	private static final long serialVersionUID = -7257248178605250086L;
	private String id;
	private String shortPlanYear;
	private String yearToBeAdjusted;
	private String shortPlanYearEndDate;
	private String startDateofNewYear;
	private String tra86DeterminationLetterReceivedDate;
	private Date gustDeterminationLetterReceivedDate;
}
