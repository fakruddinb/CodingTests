package com.genesis.core.domain.plan.service;

import java.util.List;
import java.util.Optional;


import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.genesis.core.domain.framework.exceptions.ResourceFoundException;
import com.genesis.core.domain.framework.exceptions.ResourceNotFoundException;
import com.genesis.core.domain.framework.utils.MapperUtils;
import com.genesis.core.domain.plan.domain.VestingRules;
import com.genesis.core.domain.plan.model.VestingRulesModel;
import com.genesis.core.domain.plan.repository.VestingRulesRepository;
import com.github.fge.jsonpatch.JsonPatch;
import com.github.fge.jsonpatch.JsonPatchException;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class VestingRulesService {
	
	public final VestingRulesRepository compensationRepository;
	public final MapperUtils jsonUtils;
	
	public List<VestingRulesModel> getVestingRuless() {
		return jsonUtils.mapList((List<VestingRules>) compensationRepository.findAll(), VestingRulesModel.class);
	}

	public VestingRulesModel getVestingRules(String id) {
		Optional<VestingRules> compensation = compensationRepository.findById(id);
		if (compensation.isPresent()) {
			return jsonUtils.mapObject(compensation.get(), VestingRulesModel.class);
		} else {
			throw new ResourceNotFoundException("VestingRules is not exists for given id " + id);
		}
	}

	public void deleteVestingRules(String id) {

		Optional<VestingRules> compensation = compensationRepository.findById(id);

		if (compensation.isPresent()) {
			compensationRepository.deleteById(id);
		} else {
			throw new ResourceNotFoundException("VestingRules is not exists for given id " + id);
		}

	}

	public VestingRulesModel createVestingRules(VestingRulesModel compensationModel) {

		if (compensationModel.getId() == null || !compensationRepository.findById(compensationModel.getId()).isPresent()) {

			VestingRules compensation = jsonUtils.mapObjectWithUUID(compensationModel, VestingRules.class);
			compensation = compensationRepository.save(compensation);
			return jsonUtils.mapObject(compensation, VestingRulesModel.class);
		} else {
			throw new ResourceFoundException("VestingRules is already exists for given id " + compensationModel.getId());
		}

	}

	public VestingRulesModel updateVestingRules(VestingRulesModel compensationModel) {
		String compensationID = compensationModel.getId();
		Optional<VestingRules> foundVestingRules = compensationRepository.findById(compensationID);

		if (foundVestingRules.isPresent()) {
			VestingRules compensation = jsonUtils.mapObject(compensationModel, VestingRules.class);
			compensation = compensationRepository.save(compensation);
			return jsonUtils.mapObject(compensation, VestingRulesModel.class);
		} else {
			throw new ResourceNotFoundException("VestingRules is not exists for given id " + compensationID);
		}

	}

	public VestingRulesModel patchVestingRules(String compensationId, JsonPatch compensationModel)
			throws JsonProcessingException, JsonPatchException {
		Optional<VestingRules> currentcompensation = compensationRepository.findById(compensationId);
		if (currentcompensation.isPresent()) {
			VestingRules compensation = jsonUtils.applyPatchToModel(compensationModel, currentcompensation.get(), VestingRules.class);
			compensation = compensationRepository.save(compensation);
			return jsonUtils.mapObject(compensation, VestingRulesModel.class);
		} else {
			throw new ResourceNotFoundException("VestingRules is not exists for given id " + compensationId);
		}
	}

}
