package com.genesis.core.domain.plan.controller;

import java.util.List;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.genesis.core.domain.plan.model.PlanFundModel;
import com.genesis.core.domain.plan.model.PlanModel;
import com.genesis.core.domain.plan.service.PlanFundService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/planFund")
@Tag(name = "Plan Fund")
public class PlanFundController {

	private final PlanFundService planFundSvcService;

	@Operation(summary = "Get Plan Funds", description = "Get a list of Plan Funds")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Found the Plan", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = PlanModel.class)) }),
			@ApiResponse(responseCode = "404", description = "Plans not found", content = @Content) })
	@GetMapping
	public List<PlanFundModel> getPlanFunds() throws InterruptedException {
		return planFundSvcService.getPlanFunds();
	}

	@Operation(summary = "Get Plan Fund by given Id")
	@GetMapping(value = "/{planFundId}")
	public PlanFundModel getPlanFundById(@PathVariable String planFundId) throws InterruptedException {
		return planFundSvcService.getPlanFund(planFundId);
	}

	@Operation(summary = "Create Plan Fund")
	@PostMapping
	public ResponseEntity<PlanFundModel> addPlan(@RequestBody PlanFundModel planFundModel) {
		PlanFundModel planFund = planFundSvcService.createPlanFund(planFundModel);
		return ResponseEntity.status(HttpStatus.CREATED).body(planFund);
	}

	@Operation(summary = "Update Plan")
	@PutMapping(value = "/{planId}")
	public ResponseEntity<PlanFundModel> updatePlan(@PathVariable String planId, @RequestBody PlanFundModel planFundModel) {
		planFundModel.setId(planId);
		return ResponseEntity.status(HttpStatus.OK).body(planFundSvcService.updatePlanFund(planFundModel));
	}

	@Operation(summary = "Delete Plan")
	@DeleteMapping(value = "/{planId}")
	public ResponseEntity<String> deletePlanFund(@PathVariable String planId) {
		planFundSvcService.deletePlanFund(planId);
		return ResponseEntity.status(HttpStatus.OK).body("Record is deleted");
	}

}