package com.genesis.core.domain.plan.model;

import java.io.Serializable;
import java.time.LocalDate;


import lombok.Data;

@Data
public class PlanDatesModel implements Serializable {
	private static final long serialVersionUID = -4028095267366339730L;
	private String id;
	private String startDatewithTransamerica;
	private String planAnniversary;
	private String firstAnniversaryYearEndDate;
	private String originalPlanEffectiveDate;
	private LocalDate planRestatementDate;
	private Boolean isContractTermination;
	private String planTerminationDate;
	private String affiliateEffectiveDate;
	private LocalDate frozenPlanDate;
	private String planYearBeginDate;
	private String planYearEndDate;
	private LocalDate planLimitationYearBeginDate;
	private LocalDate planLimitationYearEndDate;
	private String planFiscalYear;
	private LocalDate billingTerminationDate;
	private String planPayoutDate;
	private String affiliateTerminationDate;
	private ShortPlanDatesModel shortPlanDates;
}
