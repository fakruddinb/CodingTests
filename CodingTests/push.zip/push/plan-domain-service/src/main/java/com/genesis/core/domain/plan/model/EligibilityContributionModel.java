package com.genesis.core.domain.plan.model;

import java.io.Serializable;
import java.time.LocalDate;


import com.genesis.core.domain.plan.domain.enums.BreakPeriodOfService;
import com.genesis.core.domain.plan.domain.enums.CompPerCode;
import com.genesis.core.domain.plan.domain.enums.DisplayContribCode;

import lombok.Data;

@Data
public class EligibilityContributionModel implements Serializable{
	
	private static final long serialVersionUID = -4962526250323092851L;
	private String id;
	private CompPerCode compPerCode;
	private Boolean isIgnoreHoursRequirement;
	private BreakPeriodOfService breakPeriodOfService;
	private String rolloverContriCode;
	private Integer planFormerROContriCode;
	private LocalDate eligEfectivefDate;
	private Boolean isElectTransferPriorAllowCode;
	private Boolean isSpecialEligWaiverCode;
	private LocalDate employedOnWaiverDt;
	private DisplayContribCode displayContribCode;
	private Boolean isWaiverAmendedRestatedCode;

}
