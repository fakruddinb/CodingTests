package com.genesis.core.domain.plan.controller;

import java.util.List;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.genesis.core.domain.plan.model.PlanClassModel;
import com.genesis.core.domain.plan.model.PlanModel;
import com.genesis.core.domain.plan.service.PlanClassService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/planClass")
@Tag(name = "Plan Class")
public class PlanClassController {

	private final PlanClassService planClassSvcService;

	@Operation(summary = "Get Plan Class", description = "Get a list of Plan classes")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Found the Plan Class", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = PlanModel.class)) }),
			@ApiResponse(responseCode = "404", description = "Plan classes not found", content = @Content) })
	@GetMapping
	public List<PlanClassModel> PlanClass() throws InterruptedException {
		return planClassSvcService.getPlanClasss();
	}

	@Operation(summary = "Get Plan Class by given Id")
	@GetMapping(value = "/{planClassId}")
	public PlanClassModel getPlanClass(@PathVariable String planClassId) throws InterruptedException {
		return planClassSvcService.getPlanClass(planClassId);
	}

	@Operation(summary = "Create Plan Class")
	@PostMapping
	public ResponseEntity<PlanClassModel> addPlanClass(@RequestBody PlanClassModel planClassModel) {
		PlanClassModel planClass= planClassSvcService.createPlanClass(planClassModel);
		return ResponseEntity.status(HttpStatus.CREATED).body(planClass);
	}


	@Operation(summary = "Update Plan Class")
	@PutMapping(value = "/{planClassId}")
	public ResponseEntity<PlanClassModel> updatePlanClass(@PathVariable String planClassId,
														 @RequestBody PlanClassModel planClassModel) {
		planClassModel.setId(planClassId);
		return ResponseEntity.status(HttpStatus.OK)
				.body(planClassSvcService.updatePlanClass(planClassModel));
	}
	
	@Operation(summary = "Delete Plan Class")
	@DeleteMapping(value = "/{planClassId}")
	public ResponseEntity<String> deletePlanClass(@PathVariable String planClassId) {
		planClassSvcService.deletePlanClass(planClassId);
		return ResponseEntity.status(HttpStatus.OK).body("Record is deleted");
	}

}