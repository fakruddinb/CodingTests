package com.genesis.core.domain.plan.model;

import java.io.Serializable;
import java.time.LocalDate;


import com.genesis.core.domain.plan.domain.enums.DisplayCode;
import com.genesis.core.domain.plan.domain.enums.FundDescCode;
import com.genesis.core.domain.plan.domain.enums.FundStatus;
import com.genesis.core.domain.plan.domain.enums.RemitActionCode;

import lombok.Data;

@Data
public class PlanFundModel implements Serializable {

	private static final long serialVersionUID = -1563569888762060558L;
	private String id;
	private String planId;
	private Long provisionId;
	private String reportFundName;
	private FundDescCode fundDescCode;
	private Integer fundSequanceNo;
	private LocalDate effectiveDate;
	private LocalDate closeDate;
	private LocalDate reactivationDate;
	private FundStatus fundStatus;
	private RemitActionCode remitActionCode;
	private DisplayCode displayCode;

}
