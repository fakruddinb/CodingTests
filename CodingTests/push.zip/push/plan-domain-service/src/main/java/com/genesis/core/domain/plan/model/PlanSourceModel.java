package com.genesis.core.domain.plan.model;


import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;
import java.util.Set;


import com.genesis.core.domain.framework.domain.EntityUUID;
import com.genesis.core.domain.plan.domain.enums.InvestmentDirection;
import com.genesis.core.domain.plan.domain.enums.SourceIndicator;

import lombok.Data;

@Data
public class PlanSourceModel implements Serializable {

	private static final long serialVersionUID = -4653963071839692698L;
	private String id;
	private Long provisionId;
	private String planId;
	private Long sourceId;
	private String documentName;
	private String sourceType;
	private String translationName;
	private Integer sequenceNumber;
	private SourceIndicator sourceIndicator;
	private InvestmentDirection investmentDirection;
	private Boolean isPpaSafeHarbor;
	private LocalDate ppaQacaEffectiveDate;
	private Boolean isAnnualSafeHarborNoticeMailed;
	private String reportSourceName;
	private String safeHarborMatchContribution;
	private String autoEnrollmentcode;

		/*
		/*
	 * private Long discProRata;
		private Long perOfComp;
	 * private Boolean threeYrCatchupAllowCode; private Long
	 * hceMaxDeferA; private Boolean execHceAllowCode; private Long
	 * srcExcHceMinP; private Long srcExcHceMaxP; private String spanishDocNm;
	 * private String moneyTypeNm; private String reliusCd;
	 */
}