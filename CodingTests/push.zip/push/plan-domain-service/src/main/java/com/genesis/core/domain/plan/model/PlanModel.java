package com.genesis.core.domain.plan.model;


import com.genesis.core.domain.plan.domain.enums.*;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;


@Data
public class PlanModel implements Serializable {
	private static final long serialVersionUID = -1746600566046038780L;
	private String id;
	private Long planEnrolId;
	private Long enrolProvGroupId;
	private DefaultGroupCode defaultGroupCode;
	private Long relatedGrpId;
	private RelatedGroupTypeCode relatedgGrpTypCode;
	private String provGrpSrchName;
	private String accountNo;
	private LineOfBusiness lineOfBusiness;
	private EnrolmentStatusCode enrolStatusCode;
	private ConversionStatusCode convStatusCode;
	private LocalDate conversionDate;
	private String planNameLine1;
	private String PlanNameLine2;
	private String planName;
	//private Set<EntityUUID> fundsList = new HashSet<>();

	
	private String creationUserId;
	private LocalDate creationTS;
}
