package com.genesis.core.domain.plan.service;

import java.util.List;
import java.util.Optional;


import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.genesis.core.domain.framework.exceptions.ResourceFoundException;
import com.genesis.core.domain.framework.exceptions.ResourceNotFoundException;
import com.genesis.core.domain.framework.utils.MapperUtils;
import com.genesis.core.domain.plan.domain.PlanFund;
import com.genesis.core.domain.plan.model.PlanFundModel;
import com.genesis.core.domain.plan.repository.PlanFundRepository;
import com.github.fge.jsonpatch.JsonPatch;
import com.github.fge.jsonpatch.JsonPatchException;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PlanFundService {

	public final PlanFundRepository planFundRepository;
	public final MapperUtils jsonUtils;
	
	public List<PlanFundModel> getPlanFunds() {
		return jsonUtils.mapList((List<PlanFund>) planFundRepository.findAll(), PlanFundModel.class);
	}

	public PlanFundModel getPlanFund(String id) {
		Optional<PlanFund> planFund = planFundRepository.findById(id);
		if (planFund.isPresent()) {
			return jsonUtils.mapObject(planFund.get(), PlanFundModel.class);
		} else {
			throw new ResourceNotFoundException("PlanFund is not exists for given id " + id);
		}
	}

	public void deletePlanFund(String id) {

		Optional<PlanFund> planFund = planFundRepository.findById(id);

		if (planFund.isPresent()) {
			planFundRepository.deleteById(id);
		} else {
			throw new ResourceNotFoundException("PlanFund is not exists for given id " + id);
		}

	}

	public PlanFundModel createPlanFund(PlanFundModel planFundModel) {

		if (planFundModel.getId() == null || !planFundRepository.findById(planFundModel.getId()).isPresent()) {

			PlanFund planFund = jsonUtils.mapObjectWithUUID(planFundModel, PlanFund.class);
			planFund = planFundRepository.save(planFund);
			return jsonUtils.mapObject(planFund, PlanFundModel.class);
		} else {
			throw new ResourceFoundException("PlanFund is already exists for given id " + planFundModel.getId());
		}

	}

	public PlanFundModel updatePlanFund(PlanFundModel planFundModel) {
		String planFundID = planFundModel.getId();
		Optional<PlanFund> foundPlanFund = planFundRepository.findById(planFundID);

		if (foundPlanFund.isPresent()) {
			PlanFund planFund = jsonUtils.mapObject(planFundModel, PlanFund.class);
			planFund = planFundRepository.save(planFund);
			return jsonUtils.mapObject(planFund, PlanFundModel.class);
		} else {
			throw new ResourceNotFoundException("PlanFund is not exists for given id " + planFundID);
		}

	}

	public PlanFundModel patchPlanFund(String planFundId, JsonPatch planFundModel)
			throws JsonProcessingException, JsonPatchException {
		Optional<PlanFund> currentplanFund = planFundRepository.findById(planFundId);
		if (currentplanFund.isPresent()) {
			PlanFund planFund = jsonUtils.applyPatchToModel(planFundModel, currentplanFund.get(), PlanFund.class);
			planFund = planFundRepository.save(planFund);
			return jsonUtils.mapObject(planFund, PlanFundModel.class);
		} else {
			throw new ResourceNotFoundException("PlanFund is not exists for given id " + planFundId);
		}
	}
}
