package com.genesis.core.domain.plan.model;

import java.io.Serializable;
import java.time.LocalDate;


import com.genesis.core.domain.plan.domain.enums.AutoEsclateIncreseCode;
import com.genesis.core.domain.plan.domain.enums.EACAIndicatorCode;

import lombok.Data;

@Data
public class AutoEnrollmentModel implements Serializable {
	
	static final long serialVersionUID = 7185534441591862684L;
	private String id;

	private String planSourceId;
	private LocalDate autoEnrleffectiveDate;
	private Boolean isSixMonthRefundCode;
	private EACAIndicatorCode eacaIndicatorCode;
	private LocalDate eacaEffectiveDate;
	private Boolean isAutoEscalateFeatureCode;
	private String autoEscltP;
	private AutoEsclateIncreseCode autoEsclateIncreseCode;
	private String autoEscltMMDD;
	private LocalDate autoEscltEffDate;

}
