package com.genesis.core.domain.plan.service;

import java.util.List;
import java.util.Optional;


import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.genesis.core.domain.framework.exceptions.ResourceFoundException;
import com.genesis.core.domain.framework.exceptions.ResourceNotFoundException;
import com.genesis.core.domain.framework.utils.MapperUtils;
import com.genesis.core.domain.plan.domain.AutoEnrollment;
import com.genesis.core.domain.plan.model.AutoEnrollmentModel;
import com.genesis.core.domain.plan.repository.AutoEnrollmentRepository;
import com.github.fge.jsonpatch.JsonPatch;
import com.github.fge.jsonpatch.JsonPatchException;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AutoEnrollmentService {

	public final AutoEnrollmentRepository autoEnrollmentRepository;
	public final MapperUtils jsonUtils;
	
	public List<AutoEnrollmentModel> getAutoEnrollments() {
		return jsonUtils.mapList((List<AutoEnrollment>) autoEnrollmentRepository.findAll(), AutoEnrollmentModel.class);
	}

	public AutoEnrollmentModel getAutoEnrollment(String id) {
		Optional<AutoEnrollment> autoEnrollment = autoEnrollmentRepository.findById(id);
		if (autoEnrollment.isPresent()) {
			return jsonUtils.mapObject(autoEnrollment.get(), AutoEnrollmentModel.class);
		} else {
			throw new ResourceNotFoundException("AutoEnrollment is not exists for given id " + id);
		}
	}

	public void deleteAutoEnrollment(String id) {

		Optional<AutoEnrollment> autoEnrollment = autoEnrollmentRepository.findById(id);

		if (autoEnrollment.isPresent()) {
			autoEnrollmentRepository.deleteById(id);
		} else {
			throw new ResourceNotFoundException("AutoEnrollment is not exists for given id " + id);
		}

	}

	public AutoEnrollmentModel createAutoEnrollment(AutoEnrollmentModel autoEnrollmentModel) {

		if (autoEnrollmentModel.getId() == null || !autoEnrollmentRepository.findById(autoEnrollmentModel.getId()).isPresent()) {

			AutoEnrollment autoEnrollment = jsonUtils.mapObjectWithUUID(autoEnrollmentModel, AutoEnrollment.class);
			autoEnrollment = autoEnrollmentRepository.save(autoEnrollment);
			return jsonUtils.mapObject(autoEnrollment, AutoEnrollmentModel.class);
		} else {
			throw new ResourceFoundException("AutoEnrollment is already exists for given id " + autoEnrollmentModel.getId());
		}

	}

	public AutoEnrollmentModel updateAutoEnrollment(AutoEnrollmentModel autoEnrollmentModel) {
		String autoEnrollmentID = autoEnrollmentModel.getId();
		Optional<AutoEnrollment> foundAutoEnrollment = autoEnrollmentRepository.findById(autoEnrollmentID);

		if (foundAutoEnrollment.isPresent()) {
			AutoEnrollment autoEnrollment = jsonUtils.mapObject(autoEnrollmentModel, AutoEnrollment.class);
			autoEnrollment = autoEnrollmentRepository.save(autoEnrollment);
			return jsonUtils.mapObject(autoEnrollment, AutoEnrollmentModel.class);
		} else {
			throw new ResourceNotFoundException("AutoEnrollment is not exists for given id " + autoEnrollmentID);
		}

	}

	public AutoEnrollmentModel patchAutoEnrollment(String autoEnrollmentId, JsonPatch autoEnrollmentModel)
			throws JsonProcessingException, JsonPatchException {
		Optional<AutoEnrollment> currentautoEnrollment = autoEnrollmentRepository.findById(autoEnrollmentId);
		if (currentautoEnrollment.isPresent()) {
			AutoEnrollment autoEnrollment = jsonUtils.applyPatchToModel(autoEnrollmentModel, currentautoEnrollment.get(), AutoEnrollment.class);
			autoEnrollment = autoEnrollmentRepository.save(autoEnrollment);
			return jsonUtils.mapObject(autoEnrollment, AutoEnrollmentModel.class);
		} else {
			throw new ResourceNotFoundException("AutoEnrollment is not exists for given id " + autoEnrollmentId);
		}
	}


}
