package com.genesis.core.domain.plan.service;

import java.util.List;
import java.util.Optional;


import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.genesis.core.domain.framework.exceptions.ResourceFoundException;
import com.genesis.core.domain.framework.exceptions.ResourceNotFoundException;
import com.genesis.core.domain.framework.utils.MapperUtils;
import com.genesis.core.domain.plan.domain.PlanDates;
import com.genesis.core.domain.plan.model.PlanDatesModel;
import com.genesis.core.domain.plan.repository.PlanDateRepository;
import com.github.fge.jsonpatch.JsonPatch;
import com.github.fge.jsonpatch.JsonPatchException;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PlanDateService {

	
	public final PlanDateRepository planDateRepository;
	public final MapperUtils jsonUtils;
	
	public List<PlanDatesModel> getPlanDatess() {
		return jsonUtils.mapList((List<PlanDates>) planDateRepository.findAll(), PlanDatesModel.class);
	}

	public PlanDatesModel getPlanDates(String id) {
		Optional<PlanDates> planDate = planDateRepository.findById(id);
		if (planDate.isPresent()) {
			return jsonUtils.mapObject(planDate.get(), PlanDatesModel.class);
		} else {
			throw new ResourceNotFoundException("PlanDates is not exists for given id " + id);
		}
	}

	public void deletePlanDates(String id) {

		Optional<PlanDates> planDate = planDateRepository.findById(id);

		if (planDate.isPresent()) {
			planDateRepository.deleteById(id);
		} else {
			throw new ResourceNotFoundException("PlanDates is not exists for given id " + id);
		}

	}

	public PlanDatesModel createPlanDates(PlanDatesModel planDateModel) {

		if (planDateModel.getId() == null || !planDateRepository.findById(planDateModel.getId()).isPresent()) {

			PlanDates planDate = jsonUtils.mapObjectWithUUID(planDateModel, PlanDates.class);
			planDate = planDateRepository.save(planDate);
			return jsonUtils.mapObject(planDate, PlanDatesModel.class);
		} else {
			throw new ResourceFoundException("PlanDates is already exists for given id " + planDateModel.getId());
		}

	}

	public PlanDatesModel updatePlanDates(PlanDatesModel planDateModel) {
		String planDateID = planDateModel.getId();
		Optional<PlanDates> foundPlanDates = planDateRepository.findById(planDateID);

		if (foundPlanDates.isPresent()) {
			PlanDates planDate = jsonUtils.mapObject(planDateModel, PlanDates.class);
			planDate = planDateRepository.save(planDate);
			return jsonUtils.mapObject(planDate, PlanDatesModel.class);
		} else {
			throw new ResourceNotFoundException("PlanDates is not exists for given id " + planDateID);
		}

	}

	public PlanDatesModel patchPlanDates(String planDateId, JsonPatch planDateModel)
			throws JsonProcessingException, JsonPatchException {
		Optional<PlanDates> currentplanDate = planDateRepository.findById(planDateId);
		if (currentplanDate.isPresent()) {
			PlanDates planDate = jsonUtils.applyPatchToModel(planDateModel, currentplanDate.get(), PlanDates.class);
			planDate = planDateRepository.save(planDate);
			return jsonUtils.mapObject(planDate, PlanDatesModel.class);
		} else {
			throw new ResourceNotFoundException("PlanDates is not exists for given id " + planDateId);
		}
	}

}
