package com.genesis.core.domain.plan.model;

import java.io.Serializable;


import com.genesis.core.domain.plan.domain.enums.EquivalencyCode;
import com.genesis.core.domain.plan.domain.enums.MinAgeCode;
import com.genesis.core.domain.plan.domain.enums.ServiceReqCode;

import lombok.Data;

@Data
public class YearOfServiceRulesModel implements Serializable{
	
	private static final long serialVersionUID = -601771833221992956L;
	private String id;
	private Boolean isDefaultRuleIndCode;
	private MinAgeCode minAgeCode;
	private ServiceReqCode servReqCode;
	private EquivalencyCode equivalencyCode;
	private Integer yearlyHrsReqCount;
	private Integer rulesS;
	private String equivalencyPeriodCode;
	private Integer equivalencyHrsCount;

}
