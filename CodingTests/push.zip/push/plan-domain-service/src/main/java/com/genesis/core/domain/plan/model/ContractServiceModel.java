package com.genesis.core.domain.plan.model;

import java.io.Serializable;


import com.genesis.core.domain.plan.domain.enums.ContractIssuer;
import com.genesis.core.domain.plan.domain.enums.EmployerType;
import com.genesis.core.domain.plan.domain.enums.FundFamily;
import com.genesis.core.domain.plan.domain.enums.PaaPricingMethod;
import com.genesis.core.domain.plan.domain.enums.PaaType;
import com.genesis.core.domain.plan.domain.enums.ServiceType;

import lombok.Data;

@Data
public class ContractServiceModel implements Serializable {

	private static final long serialVersionUID = -3760879573583560709L;
	private String id;
	private ContractIssuer contractIssuer;
	private FundFamily fundFamily;
	private ServiceType serviceType;
	private EmployerType employerType;
	private PaaType paaType;
	private PaaPricingMethod paaPricingMethod;

}
