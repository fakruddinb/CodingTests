package com.genesis.core.domain.plan.model;

import com.genesis.core.domain.framework.domain.EntityUUID;
import com.genesis.core.domain.plan.domain.enums.ClassCode;
import com.genesis.core.domain.plan.domain.enums.EntryDateCode;
import lombok.Data;

import java.io.Serializable;
import java.util.Set;


@Data
public class PlanEligibilityModel implements Serializable {

	private static final long serialVersionUID = 7175105428600375832L;
	private String id;
	private String planId;
	private String sourceType;
	private Integer sourceSequenceNumber;
	private String documentName;
	private String className;
	private ClassCode classCode;
	private String exclusionCode;
	private EntryDateCode entryDateCode;


}
