package com.genesis.core.domain.plan.service;

import java.util.List;
import java.util.Optional;


import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.genesis.core.domain.framework.exceptions.ResourceFoundException;
import com.genesis.core.domain.framework.exceptions.ResourceNotFoundException;
import com.genesis.core.domain.framework.utils.MapperUtils;
import com.genesis.core.domain.plan.domain.EligibilityContribution;
import com.genesis.core.domain.plan.model.EligibilityContributionModel;
import com.genesis.core.domain.plan.repository.EligibilityContributionRepository;
import com.github.fge.jsonpatch.JsonPatch;
import com.github.fge.jsonpatch.JsonPatchException;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EligibilityContributionService {

	
	public final EligibilityContributionRepository eligibilityContributionRepository;
	public final MapperUtils jsonUtils;
	
	public List<EligibilityContributionModel> getEligibilityContributions() {
		return jsonUtils.mapList((List<EligibilityContribution>) eligibilityContributionRepository.findAll(), EligibilityContributionModel.class);
	}

	public EligibilityContributionModel getEligibilityContribution(String id) {
		Optional<EligibilityContribution> eligibilityContribution = eligibilityContributionRepository.findById(id);
		if (eligibilityContribution.isPresent()) {
			return jsonUtils.mapObject(eligibilityContribution.get(), EligibilityContributionModel.class);
		} else {
			throw new ResourceNotFoundException("EligibilityContribution is not exists for given id " + id);
		}
	}

	public void deleteEligibilityContribution(String id) {

		Optional<EligibilityContribution> eligibilityContribution = eligibilityContributionRepository.findById(id);

		if (eligibilityContribution.isPresent()) {
			eligibilityContributionRepository.deleteById(id);
		} else {
			throw new ResourceNotFoundException("EligibilityContribution is not exists for given id " + id);
		}

	}

	public EligibilityContributionModel createEligibilityContribution(EligibilityContributionModel eligibilityContributionModel) {

		if (eligibilityContributionModel.getId() == null || !eligibilityContributionRepository.findById(eligibilityContributionModel.getId()).isPresent()) {

			EligibilityContribution eligibilityContribution = jsonUtils.mapObjectWithUUID(eligibilityContributionModel, EligibilityContribution.class);
			eligibilityContribution = eligibilityContributionRepository.save(eligibilityContribution);
			return jsonUtils.mapObject(eligibilityContribution, EligibilityContributionModel.class);
		} else {
			throw new ResourceFoundException("EligibilityContribution is already exists for given id " + eligibilityContributionModel.getId());
		}

	}

	public EligibilityContributionModel updateEligibilityContribution(EligibilityContributionModel eligibilityContributionModel) {
		String eligibilityContributionID = eligibilityContributionModel.getId();
		Optional<EligibilityContribution> foundEligibilityContribution = eligibilityContributionRepository.findById(eligibilityContributionID);

		if (foundEligibilityContribution.isPresent()) {
			EligibilityContribution eligibilityContribution = jsonUtils.mapObject(eligibilityContributionModel, EligibilityContribution.class);
			eligibilityContribution = eligibilityContributionRepository.save(eligibilityContribution);
			return jsonUtils.mapObject(eligibilityContribution, EligibilityContributionModel.class);
		} else {
			throw new ResourceNotFoundException("EligibilityContribution is not exists for given id " + eligibilityContributionID);
		}

	}

	public EligibilityContributionModel patchEligibilityContribution(String eligibilityContributionId, JsonPatch eligibilityContributionModel)
			throws JsonProcessingException, JsonPatchException {
		Optional<EligibilityContribution> currenteligibilityContribution = eligibilityContributionRepository.findById(eligibilityContributionId);
		if (currenteligibilityContribution.isPresent()) {
			EligibilityContribution eligibilityContribution = jsonUtils.applyPatchToModel(eligibilityContributionModel, currenteligibilityContribution.get(), EligibilityContribution.class);
			eligibilityContribution = eligibilityContributionRepository.save(eligibilityContribution);
			return jsonUtils.mapObject(eligibilityContribution, EligibilityContributionModel.class);
		} else {
			throw new ResourceNotFoundException("EligibilityContribution is not exists for given id " + eligibilityContributionId);
		}
	}


}
