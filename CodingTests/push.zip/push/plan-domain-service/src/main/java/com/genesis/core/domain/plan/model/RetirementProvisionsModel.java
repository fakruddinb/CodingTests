package com.genesis.core.domain.plan.model;

import java.io.Serializable;


import com.genesis.core.domain.plan.domain.enums.PeriodOfServiceDefinition;
import com.genesis.core.domain.plan.domain.enums.PeriodsofServiceMeans;
import com.genesis.core.domain.plan.domain.enums.RetirementDate;

import lombok.Data;

@Data
public class RetirementProvisionsModel implements Serializable {
	private static final long serialVersionUID = -2824763858660566526L;
	private String id;
	private Integer normalRetirementAge;
	private RetirementDate normalRetirementDate;
	private String  normalRetirementOther;
	private Integer normalRetirementYearsOfService;
	private Integer earlyRetirementAge;
	private Integer earlyRetirementYearsOfService;
	private PeriodsofServiceMeans earlyRetirementPeriodsofServiceMeans;
	private PeriodOfServiceDefinition earlyRetirementPeriodofServiceDefinition403b;
	private RetirementDate earlyRetirementDate;
	private String  earlyRetirementOther;
	private String earlyRetirementPlanVests100PercentAtEarlyRetirement;

}
