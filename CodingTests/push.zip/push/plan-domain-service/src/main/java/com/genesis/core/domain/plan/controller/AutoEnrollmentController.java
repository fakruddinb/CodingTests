package com.genesis.core.domain.plan.controller;

import java.util.List;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.genesis.core.domain.plan.model.AutoEnrollmentModel;
import com.genesis.core.domain.plan.model.PlanModel;
import com.genesis.core.domain.plan.service.AutoEnrollmentService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/autoenrollment")
@Tag(name = "Auto Enrollment")
public class AutoEnrollmentController {

	private final AutoEnrollmentService autoEnrollmentSvcService;

	@Operation(summary = "Get Auto enrollments", description = "Get a list of Auto Enrollments")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Found the Plan", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = PlanModel.class)) }),
			@ApiResponse(responseCode = "404", description = "Auto Enrollments not found", content = @Content) })
	@GetMapping
	public List<AutoEnrollmentModel> autoEnrollmentModelList(){
		return autoEnrollmentSvcService.getAutoEnrollments();
	}

	@Operation(summary = "Get Auto Enrollment by given Id")
	@GetMapping(value = "/{autoEnrollmentId}")
	public AutoEnrollmentModel getAutoEnrollmentById(@PathVariable String autoEnrollmentId) {
		return autoEnrollmentSvcService.getAutoEnrollment(autoEnrollmentId);
	}

	@Operation(summary = "Create Auto Enrollment")
	@PostMapping
	public ResponseEntity<AutoEnrollmentModel> addAutoEnrollmentModel(@RequestBody AutoEnrollmentModel autoEnrollmentModel) {
		AutoEnrollmentModel autoEnrollmentModel1 = autoEnrollmentSvcService.createAutoEnrollment(autoEnrollmentModel);
		return ResponseEntity.status(HttpStatus.CREATED).body(autoEnrollmentModel1);
	}


	@Operation(summary = "Update Auto Enrollment")
	@PutMapping(value = "/{autoEnrollmentId}")
	public ResponseEntity<AutoEnrollmentModel> updateAutoEnrollment(@PathVariable String autoEnrollmentId,
														 @RequestBody AutoEnrollmentModel autoEnrollmentModel) {
		autoEnrollmentModel.setId(autoEnrollmentId);
		return ResponseEntity.status(HttpStatus.OK)
				.body(autoEnrollmentSvcService.updateAutoEnrollment(autoEnrollmentModel));
	}
	
	@Operation(summary = "Delete Auto Enrollment")
	@DeleteMapping(value = "/{autoEnrollmentId}")
	public ResponseEntity<String> deletePlan(@PathVariable String autoEnrollmentId) {
		autoEnrollmentSvcService.deleteAutoEnrollment(autoEnrollmentId);
		return ResponseEntity.status(HttpStatus.OK).body("Record is deleted");
	}

}