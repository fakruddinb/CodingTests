package com.genesis.core.domain.plan.model;

import java.io.Serializable;


import lombok.Data;

@Data
public class YearlyEligibilityRulesModel implements Serializable{
	
	private static final long serialVersionUID = -157580521135785654L;
	private String id;
	private Boolean isElapseTimeIndCode;
	private Integer elapseTimeMonthNo;
	private Boolean isDeathEligReqCode;
	private String yearlyEligText;
	private String yearlyHrsReqInd;

}
