package com.genesis.core.domain.plan.model;

import java.io.Serializable;


import lombok.Data;

@Data
public class PartnerModel implements Serializable {
	private static final long serialVersionUID = -8043150568037956342L;
	private String id;
	private Integer serviceModel;
}
