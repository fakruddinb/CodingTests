package com.genesis.core.domain.plan.model;

import java.io.Serializable;


import lombok.Data;

@Data
public class PlanProvisionsModel implements Serializable {

	private static final long serialVersionUID = -8127438640983049284L;
	private String id;
	private	Boolean	loansPermitted;
	private	Boolean	inServiceWithdrawalsPermitted;
	private	Boolean	hardshipWithdrawalsPermitted;
	private	Boolean	multipleInserviceWDTypesAllowed;
	private	Boolean	isManagedAdvise;
}
