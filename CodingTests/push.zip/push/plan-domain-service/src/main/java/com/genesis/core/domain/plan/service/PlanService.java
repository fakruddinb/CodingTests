package com.genesis.core.domain.plan.service;

import java.util.List;
import java.util.Optional;


import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.genesis.core.domain.framework.exceptions.ResourceFoundException;
import com.genesis.core.domain.framework.exceptions.ResourceNotFoundException;
import com.genesis.core.domain.framework.utils.MapperUtils;
import com.genesis.core.domain.plan.domain.Plan;
import com.genesis.core.domain.plan.model.PlanModel;
import com.genesis.core.domain.plan.repository.PlanRepository;
import com.github.fge.jsonpatch.JsonPatch;
import com.github.fge.jsonpatch.JsonPatchException;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PlanService {

	public final PlanRepository planRepository;
	public final MapperUtils jsonUtils;
	
	public List<PlanModel> getPlans() {
		return jsonUtils.mapList((List<Plan>) planRepository.findAll(), PlanModel.class);
	}

	public PlanModel getPlan(String id) {
		Optional<Plan> plan = planRepository.findById(id);
		if (plan.isPresent()) {
			return jsonUtils.mapObject(plan.get(), PlanModel.class);
		} else {
			throw new ResourceNotFoundException("Plan is not exists for given id " + id);
		}
	}

	public void deletePlan(String id) {

		Optional<Plan> plan = planRepository.findById(id);

		if (plan.isPresent()) {
			planRepository.deleteById(id);
		} else {
			throw new ResourceNotFoundException("Plan is not exists for given id " + id);
		}

	}

	public PlanModel createPlan(PlanModel planModel) {

		if (planModel.getId() == null || !planRepository.findById(planModel.getId()).isPresent()) {

			Plan plan = jsonUtils.mapObjectWithUUID(planModel, Plan.class);
			plan = planRepository.save(plan);
			return jsonUtils.mapObject(plan, PlanModel.class);
		} else {
			throw new ResourceFoundException("Plan is already exists for given id " + planModel.getId());
		}

	}

	public PlanModel updatePlan(PlanModel planModel) {
		String planID = planModel.getId();
		Optional<Plan> foundPlan = planRepository.findById(planID);

		if (foundPlan.isPresent()) {
			Plan plan = jsonUtils.mapObject(planModel, Plan.class);
			plan = planRepository.save(plan);
			return jsonUtils.mapObject(plan, PlanModel.class);
		} else {
			throw new ResourceNotFoundException("Plan is not exists for given id " + planID);
		}

	}

	public PlanModel patchPlan(String planId, JsonPatch planModel)
			throws JsonProcessingException, JsonPatchException {
		Optional<Plan> currentplan = planRepository.findById(planId);
		if (currentplan.isPresent()) {
			Plan plan = jsonUtils.applyPatchToModel(planModel, currentplan.get(), Plan.class);
			plan = planRepository.save(plan);
			return jsonUtils.mapObject(plan, PlanModel.class);
		} else {
			throw new ResourceNotFoundException("Plan is not exists for given id " + planId);
		}
	}
}
