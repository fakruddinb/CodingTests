package com.genesis.core.domain.plan.service;

import java.util.List;
import java.util.Optional;


import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.genesis.core.domain.framework.exceptions.ResourceFoundException;
import com.genesis.core.domain.framework.exceptions.ResourceNotFoundException;
import com.genesis.core.domain.framework.utils.MapperUtils;
import com.genesis.core.domain.plan.domain.Partner;
import com.genesis.core.domain.plan.model.PartnerModel;
import com.genesis.core.domain.plan.repository.PartnerRepository;
import com.github.fge.jsonpatch.JsonPatch;
import com.github.fge.jsonpatch.JsonPatchException;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PartnerService {
	
	public final PartnerRepository partnerRepository;
	public final MapperUtils jsonUtils;
	
	public List<PartnerModel> getPartners() {
		return jsonUtils.mapList((List<Partner>) partnerRepository.findAll(), PartnerModel.class);
	}

	public PartnerModel getPartner(String id) {
		Optional<Partner> partner = partnerRepository.findById(id);
		if (partner.isPresent()) {
			return jsonUtils.mapObject(partner.get(), PartnerModel.class);
		} else {
			throw new ResourceNotFoundException("Partner is not exists for given id " + id);
		}
	}

	public void deletePartner(String id) {

		Optional<Partner> partner = partnerRepository.findById(id);

		if (partner.isPresent()) {
			partnerRepository.deleteById(id);
		} else {
			throw new ResourceNotFoundException("Partner is not exists for given id " + id);
		}

	}

	public PartnerModel createPartner(PartnerModel partnerModel) {

		if (partnerModel.getId() == null || !partnerRepository.findById(partnerModel.getId()).isPresent()) {

			Partner partner = jsonUtils.mapObjectWithUUID(partnerModel, Partner.class);
			partner = partnerRepository.save(partner);
			return jsonUtils.mapObject(partner, PartnerModel.class);
		} else {
			throw new ResourceFoundException("Partner is already exists for given id " + partnerModel.getId());
		}

	}

	public PartnerModel updatePartner(PartnerModel partnerModel) {
		String partnerID = partnerModel.getId();
		Optional<Partner> foundPartner = partnerRepository.findById(partnerID);

		if (foundPartner.isPresent()) {
			Partner partner = jsonUtils.mapObject(partnerModel, Partner.class);
			partner = partnerRepository.save(partner);
			return jsonUtils.mapObject(partner, PartnerModel.class);
		} else {
			throw new ResourceNotFoundException("Partner is not exists for given id " + partnerID);
		}

	}

	public PartnerModel patchPartner(String partnerId, JsonPatch partnerModel)
			throws JsonProcessingException, JsonPatchException {
		Optional<Partner> currentpartner = partnerRepository.findById(partnerId);
		if (currentpartner.isPresent()) {
			Partner partner = jsonUtils.applyPatchToModel(partnerModel, currentpartner.get(), Partner.class);
			partner = partnerRepository.save(partner);
			return jsonUtils.mapObject(partner, PartnerModel.class);
		} else {
			throw new ResourceNotFoundException("Partner is not exists for given id " + partnerId);
		}
	}

}
