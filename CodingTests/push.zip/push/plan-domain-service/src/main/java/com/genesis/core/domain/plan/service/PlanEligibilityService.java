package com.genesis.core.domain.plan.service;

import java.util.List;
import java.util.Optional;


import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.genesis.core.domain.framework.exceptions.ResourceFoundException;
import com.genesis.core.domain.framework.exceptions.ResourceNotFoundException;
import com.genesis.core.domain.framework.utils.MapperUtils;
import com.genesis.core.domain.plan.domain.PlanEligibility;
import com.genesis.core.domain.plan.model.PlanEligibilityModel;
import com.genesis.core.domain.plan.repository.PlanEligibilityRepository;
import com.github.fge.jsonpatch.JsonPatch;
import com.github.fge.jsonpatch.JsonPatchException;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PlanEligibilityService {

	
	public final PlanEligibilityRepository planEligibilityRepository;
	public final MapperUtils jsonUtils;
	
	public List<PlanEligibilityModel> getPlanEligibilitys() {
		return jsonUtils.mapList((List<PlanEligibility>) planEligibilityRepository.findAll(), PlanEligibilityModel.class);
	}

	public PlanEligibilityModel getPlanEligibility(String id) {
		Optional<PlanEligibility> planEligibility = planEligibilityRepository.findById(id);
		if (planEligibility.isPresent()) {
			return jsonUtils.mapObject(planEligibility.get(), PlanEligibilityModel.class);
		} else {
			throw new ResourceNotFoundException("PlanEligibility is not exists for given id " + id);
		}
	}

	public void deletePlanEligibility(String id) {

		Optional<PlanEligibility> planEligibility = planEligibilityRepository.findById(id);

		if (planEligibility.isPresent()) {
			planEligibilityRepository.deleteById(id);
		} else {
			throw new ResourceNotFoundException("PlanEligibility is not exists for given id " + id);
		}

	}

	public PlanEligibilityModel createPlanEligibility(PlanEligibilityModel planEligibilityModel) {

		if (planEligibilityModel.getId() == null || !planEligibilityRepository.findById(planEligibilityModel.getId()).isPresent()) {

			PlanEligibility planEligibility = jsonUtils.mapObjectWithUUID(planEligibilityModel, PlanEligibility.class);
			planEligibility = planEligibilityRepository.save(planEligibility);
			return jsonUtils.mapObject(planEligibility, PlanEligibilityModel.class);
		} else {
			throw new ResourceFoundException("PlanEligibility is already exists for given id " + planEligibilityModel.getId());
		}

	}

	public PlanEligibilityModel updatePlanEligibility(PlanEligibilityModel planEligibilityModel) {
		String planEligibilityID = planEligibilityModel.getId();
		Optional<PlanEligibility> foundPlanEligibility = planEligibilityRepository.findById(planEligibilityID);

		if (foundPlanEligibility.isPresent()) {
			PlanEligibility planEligibility = jsonUtils.mapObject(planEligibilityModel, PlanEligibility.class);
			planEligibility = planEligibilityRepository.save(planEligibility);
			return jsonUtils.mapObject(planEligibility, PlanEligibilityModel.class);
		} else {
			throw new ResourceNotFoundException("PlanEligibility is not exists for given id " + planEligibilityID);
		}

	}

	public PlanEligibilityModel patchPlanEligibility(String planEligibilityId, JsonPatch planEligibilityModel)
			throws JsonProcessingException, JsonPatchException {
		Optional<PlanEligibility> currentplanEligibility = planEligibilityRepository.findById(planEligibilityId);
		if (currentplanEligibility.isPresent()) {
			PlanEligibility planEligibility = jsonUtils.applyPatchToModel(planEligibilityModel, currentplanEligibility.get(), PlanEligibility.class);
			planEligibility = planEligibilityRepository.save(planEligibility);
			return jsonUtils.mapObject(planEligibility, PlanEligibilityModel.class);
		} else {
			throw new ResourceNotFoundException("PlanEligibility is not exists for given id " + planEligibilityId);
		}
	}


}
