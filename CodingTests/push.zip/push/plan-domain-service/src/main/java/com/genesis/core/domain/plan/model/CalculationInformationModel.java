package com.genesis.core.domain.plan.model;

import java.io.Serializable;


import com.genesis.core.domain.plan.domain.enums.CalculationOfContribution;

import lombok.Data;

@Data
public class CalculationInformationModel implements Serializable {
	
	private static final long serialVersionUID = -4536405693844332935L;
	private String id;
	private CalculationOfContribution calculationOfContribution;
	private String ctrbCalcDescT;
	private Boolean isAannualMatchCode;
	private Boolean isMatchIncludedTrueUpCalCode;
	private Boolean isConditionedOnProfitCode;
	private Boolean isCombinedDeferralsCode;
	private Integer catchupMatchContribution;
	
}
