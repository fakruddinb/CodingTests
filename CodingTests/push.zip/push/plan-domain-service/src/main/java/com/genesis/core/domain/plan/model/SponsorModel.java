package com.genesis.core.domain.plan.model;

import java.io.Serializable;


import com.genesis.core.domain.plan.domain.enums.ChurchPlanEntityType;
import com.genesis.core.domain.plan.domain.enums.Classification;
import com.genesis.core.domain.plan.domain.enums.EntityOfPlanSponsor;
import com.genesis.core.domain.plan.domain.enums.IRSBusinessTaxCode;
import com.genesis.core.domain.plan.domain.enums.PlanEntity;

import lombok.Data;

@Data
public class SponsorModel implements Serializable  {
	private static final long serialVersionUID = 2479471324983404677L;
	private String id;
	private EntityOfPlanSponsor entityofPlanSponsor;
	private String controlledGroupName;
	private PlanEntity planEntity;
	private String planSponsorIdentification;
	private IRSBusinessTaxCode irsBusinessTaxCode;
	private Classification classisication;
	private String isThePlanPubliclyTraded;
	private ChurchPlanEntityType churchPlanEntityType;

}
