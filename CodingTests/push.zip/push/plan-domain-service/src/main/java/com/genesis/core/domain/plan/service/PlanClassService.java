package com.genesis.core.domain.plan.service;

import java.util.List;
import java.util.Optional;


import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.genesis.core.domain.framework.exceptions.ResourceFoundException;
import com.genesis.core.domain.framework.exceptions.ResourceNotFoundException;
import com.genesis.core.domain.framework.utils.MapperUtils;
import com.genesis.core.domain.plan.domain.PlanClass;
import com.genesis.core.domain.plan.model.PlanClassModel;
import com.genesis.core.domain.plan.repository.PlanClassRepository;
import com.github.fge.jsonpatch.JsonPatch;
import com.github.fge.jsonpatch.JsonPatchException;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PlanClassService {

	
	public final PlanClassRepository planClassRepository;
	public final MapperUtils jsonUtils;
	
	public List<PlanClassModel> getPlanClasss() {
		return jsonUtils.mapList((List<PlanClass>) planClassRepository.findAll(), PlanClassModel.class);
	}

	public PlanClassModel getPlanClass(String id) {
		Optional<PlanClass> planClass = planClassRepository.findById(id);
		if (planClass.isPresent()) {
			return jsonUtils.mapObject(planClass.get(), PlanClassModel.class);
		} else {
			throw new ResourceNotFoundException("PlanClass is not exists for given id " + id);
		}
	}

	public void deletePlanClass(String id) {

		Optional<PlanClass> planClass = planClassRepository.findById(id);

		if (planClass.isPresent()) {
			planClassRepository.deleteById(id);
		} else {
			throw new ResourceNotFoundException("PlanClass is not exists for given id " + id);
		}

	}

	public PlanClassModel createPlanClass(PlanClassModel planClassModel) {

		if (planClassModel.getId() == null || !planClassRepository.findById(planClassModel.getId()).isPresent()) {

			PlanClass planClass = jsonUtils.mapObjectWithUUID(planClassModel, PlanClass.class);
			planClass = planClassRepository.save(planClass);
			return jsonUtils.mapObject(planClass, PlanClassModel.class);
		} else {
			throw new ResourceFoundException("PlanClass is already exists for given id " + planClassModel.getId());
		}

	}

	public PlanClassModel updatePlanClass(PlanClassModel planClassModel) {
		String planClassID = planClassModel.getId();
		Optional<PlanClass> foundPlanClass = planClassRepository.findById(planClassID);

		if (foundPlanClass.isPresent()) {
			PlanClass planClass = jsonUtils.mapObject(planClassModel, PlanClass.class);
			planClass = planClassRepository.save(planClass);
			return jsonUtils.mapObject(planClass, PlanClassModel.class);
		} else {
			throw new ResourceNotFoundException("PlanClass is not exists for given id " + planClassID);
		}

	}

	public PlanClassModel patchPlanClass(String planClassId, JsonPatch planClassModel)
			throws JsonProcessingException, JsonPatchException {
		Optional<PlanClass> currentplanClass = planClassRepository.findById(planClassId);
		if (currentplanClass.isPresent()) {
			PlanClass planClass = jsonUtils.applyPatchToModel(planClassModel, currentplanClass.get(), PlanClass.class);
			planClass = planClassRepository.save(planClass);
			return jsonUtils.mapObject(planClass, PlanClassModel.class);
		} else {
			throw new ResourceNotFoundException("PlanClass is not exists for given id " + planClassId);
		}
	}
}
