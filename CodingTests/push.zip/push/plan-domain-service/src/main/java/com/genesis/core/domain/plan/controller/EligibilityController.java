package com.genesis.core.domain.plan.controller;

import java.util.List;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.genesis.core.domain.plan.model.PlanEligibilityModel;
import com.genesis.core.domain.plan.model.PlanModel;
import com.genesis.core.domain.plan.service.PlanEligibilityService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/eligibility")
@Tag(name = "Eligibility")
public class EligibilityController {

	private final PlanEligibilityService eligibilitySvcService;

	@Operation(summary = "Get Eligibility", description = "Get a list of Eligibilities")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Found the Plan", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = PlanModel.class)) }),
			@ApiResponse(responseCode = "404", description = "Plans not found", content = @Content) })
	@GetMapping
	public List<PlanEligibilityModel> getPlanEligibilities() throws InterruptedException {
		return eligibilitySvcService.getPlanEligibilitys();
	}

	@Operation(summary = "Get Eligibility by given Id")
	@GetMapping(value = "/{eligibilityId}")
	public PlanEligibilityModel getEligibility(@PathVariable String eligibilityId) throws InterruptedException {
		return eligibilitySvcService.getPlanEligibility(eligibilityId);
	}

	@Operation(summary = "Create Eligibility")
	@PostMapping
	public ResponseEntity<PlanEligibilityModel> addPlanEligibilityM(@RequestBody PlanEligibilityModel planEligibilityModel) {
		PlanEligibilityModel newPlan= eligibilitySvcService.createPlanEligibility(planEligibilityModel);
		return ResponseEntity.status(HttpStatus.CREATED).body(newPlan);
	}


	@Operation(summary = "Update Eligibility")
	@PutMapping(value = "/{eligibilityId}")
	public ResponseEntity<PlanEligibilityModel> updatePlanEligibilityM(@PathVariable String eligibilityId,
														 @RequestBody PlanEligibilityModel planEligibilityModel) {
		planEligibilityModel.setId(eligibilityId);
		return ResponseEntity.status(HttpStatus.OK)
				.body(eligibilitySvcService.updatePlanEligibility(planEligibilityModel));
	}
	
	@Operation(summary = "Delete Eligibility")
	@DeleteMapping(value = "/{eligibilityId}")
	public ResponseEntity<String> deletePlanEligibility(@PathVariable String eligibilityId) {
		eligibilitySvcService.deletePlanEligibility(eligibilityId);
		return ResponseEntity.status(HttpStatus.OK).body("Record is deleted");
	}

}