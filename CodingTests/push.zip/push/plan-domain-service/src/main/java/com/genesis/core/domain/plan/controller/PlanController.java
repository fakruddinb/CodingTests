package com.genesis.core.domain.plan.controller;

import java.util.List;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.genesis.core.domain.plan.model.PlanModel;
import com.genesis.core.domain.plan.service.PlanService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/plan")
@Tag(name = "Plan")
public class PlanController {

	private final PlanService planSvcService;

	@Operation(summary = "Get Plans", description = "Get a list of Plans")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Found the Plan", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = PlanModel.class)) }),
			@ApiResponse(responseCode = "404", description = "Plans not found", content = @Content) })
	@GetMapping
	public List<PlanModel> Plans() throws InterruptedException {
		return planSvcService.getPlans();
	}

	@Operation(summary = "Get Plan by given Id")
	@GetMapping(value = "/{planId}")
	public PlanModel getPlans(@PathVariable String planId) throws InterruptedException {
		return planSvcService.getPlan(planId);
	}

	@Operation(summary = "Create Plan")
	@PostMapping
	public ResponseEntity<PlanModel> addPlan(@RequestBody PlanModel planModel) {
		PlanModel newPlan= planSvcService.createPlan(planModel);
		return ResponseEntity.status(HttpStatus.CREATED).body(newPlan);
	}


	@Operation(summary = "Update Plan")
	@PutMapping(value = "/{planId}")
	public ResponseEntity<PlanModel> updatePlan(@PathVariable String planId,
														 @RequestBody PlanModel planModel) {
		planModel.setId(planId);
		return ResponseEntity.status(HttpStatus.OK)
				.body(planSvcService.updatePlan(planModel));
	}
	
	@Operation(summary = "Delete Plan")
	@DeleteMapping(value = "/{planId}")
	public ResponseEntity<String> deletePlan(@PathVariable String planId) {
		planSvcService.deletePlan(planId);
		return ResponseEntity.status(HttpStatus.OK).body("Record is deleted");
	}

}