package com.genesis.core.domain.plan.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;


import com.genesis.core.domain.plan.domain.enums.ClassCode;
import com.genesis.core.domain.plan.domain.enums.ClassTypeCode;

import lombok.Data;

@Data
public class PlanClassModel implements Serializable {

	private static final long serialVersionUID = -7557689682921586672L;
	private String id;
	private String planId;
	private Long classProvI;
	private Long classI;
	private ClassTypeCode classTypeCode;
	private String className;
	private ClassCode classCode;
	private String exclusionCode;
	private LocalDate effectiveDate;
	private String status;
	private String compPeriodCode;
	private String userId;
	private LocalDate creationTS;

}
