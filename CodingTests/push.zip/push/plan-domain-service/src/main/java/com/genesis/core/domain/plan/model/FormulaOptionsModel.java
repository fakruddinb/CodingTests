package com.genesis.core.domain.plan.model;

import java.io.Serializable;


import lombok.Data;

@Data
public class FormulaOptionsModel implements Serializable{
	
	private static final long serialVersionUID = -838343682826626463L;
	private String id;
	private String formulaC;
	private String integratedLvLCd;
	private String integratedLvLCdDesc;
	private String formulaT;
	private Double sourceMaxP;
	private Double sourceMinP;
	private Double sourceMinA;
	private Double bkptXValP;

}
