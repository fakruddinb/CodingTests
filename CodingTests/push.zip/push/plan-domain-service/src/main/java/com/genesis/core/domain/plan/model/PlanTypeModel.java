package com.genesis.core.domain.plan.model;

import java.io.Serializable;


import com.genesis.core.domain.plan.domain.enums.ApplyPlanLevelDisclosures;
import com.genesis.core.domain.plan.domain.enums.DocumentType;
import com.genesis.core.domain.plan.domain.enums.EProspectusCode;
import com.genesis.core.domain.plan.domain.enums.PlanTypeCode;
import com.genesis.core.domain.plan.domain.enums.PlanTypeDescription;
import com.genesis.core.domain.plan.domain.enums.PriorCarrier;
import com.genesis.core.domain.plan.domain.enums.PriorCarrierPlantype;
import com.genesis.core.domain.plan.domain.enums.RothPlan;
import com.genesis.core.domain.plan.domain.enums.Segmentation;
import com.genesis.core.domain.plan.domain.enums.VoluntaryCode;

import lombok.Data;

@Data
public class PlanTypeModel implements Serializable  {
	private static final long serialVersionUID = -1034343778140237708L;
	private String id;
	private Boolean isSoleCarrier;
	private Boolean isComparabilityPlan;
	private Boolean isPcraRemitAccount;
	private Boolean isAgeWeightedPlan;
	private Boolean isApplyParticipantFeeDisclosure;
	private Boolean isInvestmentReporting;
	private Boolean isEmployerStockCostBasisBySource;
	private Boolean isMigrated;
	private EProspectusCode eProspectusCode;
	private Boolean isParticipantInvestmentMaterialOverride;
	private Double interestRate;
	private Boolean isClarkOneAlignment;
	private PriorCarrier priorCarrier;
	private DocumentType documentType;
	private VoluntaryCode voluntaryCode;
	private PlanTypeCode planType;
	private PlanTypeDescription planTypeDescription;
	private Boolean isBrokerageSelectSDA;
	private Boolean isTotalRetirementOutsourcing;
	private Boolean isAllowServiceOnlyFunds;
	private PriorCarrierPlantype priorCarrierPlantype;
	private Segmentation segmentation;
	private String plan;
	private Boolean isErisaLoanRateAllowed;
	private Boolean erisaPlan;
	private RothPlan rothPlan;
	private Boolean isInPlanRothconversionsAllowed;
	private String mortalityTable;
	private ApplyPlanLevelDisclosures applyPlanLevelDisclosures;
	private String employerId;
	private String clientId;

}
