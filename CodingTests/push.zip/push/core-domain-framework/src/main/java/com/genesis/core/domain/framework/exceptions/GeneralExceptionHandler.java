package com.genesis.core.domain.framework.exceptions;

import java.time.LocalDateTime;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.genesis.core.domain.framework.model.ResponseModel;
import com.github.fge.jsonpatch.JsonPatchException;

@RestControllerAdvice
public class GeneralExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<Object> resourceNotFoundException(ResourceNotFoundException ex, WebRequest request) {
        return new ResponseEntity<Object>(new ResponseModel("{}",
                HttpStatus.OK,
                LocalDateTime.now(),
                ex.getErrorCode(),
                ex.getMessage()), HttpStatus.OK);
    }
    
    @ExceptionHandler(ResourceFoundException.class)
    public ResponseEntity<Object> resourceFoundException(ResourceFoundException ex, WebRequest request) {
        return new ResponseEntity<Object>(new ResponseModel("{}",
                HttpStatus.OK,
                LocalDateTime.now(),
                ex.getErrorCode(),
                ex.getMessage()), HttpStatus.OK);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Object> illegalArgumentException(IllegalArgumentException ex, WebRequest request) {
        return new ResponseEntity<Object>(new ResponseModel(null,
                HttpStatus.OK,
                LocalDateTime.now(),
                "2005",
                ex.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<Object> constraintViolationException(ConstraintViolationException ex, WebRequest request) {
        String errors = ex.getConstraintViolations().stream().map(ConstraintViolation::getMessage)
                .collect(Collectors.joining(", "));
        return new ResponseEntity<>(new ResponseModel(null,
                HttpStatus.BAD_REQUEST,
                LocalDateTime.now(),
                null,
                errors), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(JsonPatchException.class)
    public ResponseEntity<Object> jsonPatchException(JsonPatchException ex, WebRequest request) {
        return new ResponseEntity<>(new ResponseModel(null,
                HttpStatus.BAD_REQUEST,
                LocalDateTime.now(),
                null,
                ex.getMessage()), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(JsonProcessingException.class)
    public ResponseEntity<Object> jsonPatchException(JsonProcessingException ex, WebRequest request) {
        return new ResponseEntity<>(new ResponseModel(null,
                HttpStatus.BAD_REQUEST,
                LocalDateTime.now(),
                null,
                ex.getMessage()), HttpStatus.BAD_REQUEST);
    }

    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(
            HttpMessageNotReadableException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        ResponseModel responseModel = new ResponseModel(null,
                HttpStatus.BAD_REQUEST, LocalDateTime.now(), null, ex.getMessage());
        return new ResponseEntity<Object>(responseModel, HttpStatus.BAD_REQUEST);
    }


    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        String errors = ex.getBindingResult().getAllErrors().stream()
                .map(DefaultMessageSourceResolvable::getDefaultMessage)
                .collect(java.util.stream.Collectors.joining(", "));
        ResponseModel responseModel = new ResponseModel(errors,
                HttpStatus.BAD_REQUEST, LocalDateTime.now(), null, errors);
        return new ResponseEntity<>(responseModel, HttpStatus.BAD_REQUEST);
    }

    @Override
    protected ResponseEntity<Object> handleNoHandlerFoundException(NoHandlerFoundException ex, HttpHeaders headers,
                                                                   HttpStatus status, WebRequest request) {
        return new ResponseEntity<Object>(new ResponseModel(null,
                HttpStatus.NOT_FOUND,
                LocalDateTime.now(),
                "NO HANDLER",
                ex.getMessage()), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(DuplicateResourceException.class)
    public ResponseEntity<Object> resourceDuplicateException(DuplicateResourceException ex, WebRequest request) {
        return new ResponseEntity<Object>(new ResponseModel("{}",
                HttpStatus.BAD_REQUEST,
                LocalDateTime.now(),
                ex.getErrorCode(),
                ex.getMessage()), HttpStatus.OK);
    }
}
