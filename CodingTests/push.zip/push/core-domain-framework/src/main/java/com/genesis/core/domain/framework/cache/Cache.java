package com.genesis.core.domain.framework.cache;

import java.util.Collection;
import java.util.List;

/**
 * Interface for getting a cache instance/info with a cache config
 *
 * @param <T> Type of cache instance
 * @param <K> Type of cache config
 */
public interface Cache<T, K> {
	
	K getConfig();
	T getCacheInstance();
	
	List<String> getAddresses();
	Collection<Integer> getPorts();
	String getInstanceName();
	String getClusterName();
}
