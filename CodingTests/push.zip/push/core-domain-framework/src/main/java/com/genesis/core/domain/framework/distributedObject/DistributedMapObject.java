package com.genesis.core.domain.framework.distributedObject;

import com.genesis.core.domain.framework.predicateQuery.BiPredicateQuery;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

public interface DistributedMapObject<K, V, P extends BiPredicateQuery<K, V>> {
  CompletableFuture<V> saveAsync(K key, V value);

  V save(K key, V value);

  void saveAll(Map<K, V> values);

  CompletableFuture<V> getAsync(K key);

  V get(K key);

  CompletableFuture<V> removeAsync(K key);

  V remove(K key);

  void removeAll(List<K> keys);

  void removeIf(P query);

  Set<K> getKeysAsSet();

  List<V> getValuesAsList();

  Set<Map.Entry<K, V>> queryEntriesAsSet(P query);
  
  Collection<V> getByQuery(String query);
}