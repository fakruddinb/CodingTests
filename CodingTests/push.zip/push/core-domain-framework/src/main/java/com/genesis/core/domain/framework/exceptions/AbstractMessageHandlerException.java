package com.genesis.core.domain.framework.exceptions;

public abstract class AbstractMessageHandlerException extends RuntimeException {
}
