package com.genesis.core.domain.framework.exceptions;

public class DuplicateResourceException extends BaseException {

	private static final long serialVersionUID = 5619738500140887135L;

	public DuplicateResourceException(String message) {
		super(message);
	}
	
	public DuplicateResourceException(String errorCode, String message) {
		super(message, errorCode);
	}

}
