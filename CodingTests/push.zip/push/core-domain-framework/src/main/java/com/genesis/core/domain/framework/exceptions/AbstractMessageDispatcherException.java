package com.genesis.core.domain.framework.exceptions;

public abstract class AbstractMessageDispatcherException extends RuntimeException {
}
