package com.genesis.core.domain.framework.cache;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.hazelcast.repository.config.EnableHazelcastRepositories;

import com.hazelcast.client.HazelcastClient;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.core.HazelcastInstance;

@Configuration
@EnableHazelcastRepositories(basePackages = {"com.genesis.core.domain"})
public class HazelcastCacheConfig {

	private static final String clientIp = "172.19.70.59";
	private static final String clientCluster = "transamerica-hazelcast-cluster";

	@Bean
	public ClientConfig getConfig() {
		ClientConfig clientConfig = new ClientConfig();
		//clientConfig.getNetworkConfig().addAddress(clientIp);
		//clientConfig.setClusterName(clientCluster);
		return clientConfig;
	}

	@Bean
	public HazelcastInstance hazelcastInstance(ClientConfig cacheConfig) {
		return HazelcastClient.newHazelcastClient(cacheConfig);
	}
}
