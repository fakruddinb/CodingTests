package com.genesis.core.domain.framework.exceptions;

abstract public class AbstractEntityValidationException extends RuntimeException {
}
