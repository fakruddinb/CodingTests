package com.genesis.core.domain.framework.exceptions;

public abstract class AbstractAggregateRootValidationException extends RuntimeException {
}
