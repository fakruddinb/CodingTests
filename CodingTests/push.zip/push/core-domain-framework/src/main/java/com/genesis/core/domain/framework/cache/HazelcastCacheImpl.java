package com.genesis.core.domain.framework.cache;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.core.HazelcastInstance;

@Service
public class HazelcastCacheImpl implements Cache<HazelcastInstance, ClientConfig> {

	@Autowired
	private ClientConfig clientConfig;

	@Autowired
	private HazelcastInstance hazelcastInstance;

	@Override
	public ClientConfig getConfig() {
		return this.clientConfig;
	}

	@Override
	public HazelcastInstance getCacheInstance() {
		return this.hazelcastInstance;
	}

	@Override
	public List<String> getAddresses() {
		return this.clientConfig.getNetworkConfig().getAddresses();
	}

	@Override
	public Collection<Integer> getPorts() {
		return this.clientConfig.getNetworkConfig().getOutboundPorts();
	}

	@Override
	public String getInstanceName() {
		return this.clientConfig.getInstanceName();
	}

	@Override
	public String getClusterName() {
		return this.clientConfig.getClusterName();
	}

}
