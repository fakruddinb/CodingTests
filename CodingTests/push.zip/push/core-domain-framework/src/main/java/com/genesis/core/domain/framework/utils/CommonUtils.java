package com.genesis.core.domain.framework.utils;

import com.genesis.core.domain.framework.domain.AggregateRootUUID;
import com.genesis.core.domain.framework.domain.EntityUUID;

import java.util.UUID;

public class CommonUtils {

    public static UUID getUUID(){
        return UUID.randomUUID();
    }
    
    public static String getUUIDString(){
        return UUID.randomUUID().toString();
    }

    public static EntityUUID getEntityId(UUID uuid){
        return new EntityUUID(uuid);
    }

    public static EntityUUID getEntityId(){
        return new EntityUUID(getUUID());
    }

    public static AggregateRootUUID getAggregateRootUUID(){
        return new AggregateRootUUID(getUUID());
    }

}
