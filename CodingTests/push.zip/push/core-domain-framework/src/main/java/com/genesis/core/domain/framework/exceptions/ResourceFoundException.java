package com.genesis.core.domain.framework.exceptions;

public class ResourceFoundException extends BaseException {
	
	private static final long serialVersionUID = 6177312724928007333L;

	public ResourceFoundException(String errorCode, String message) {
		super(message, errorCode);
	}
	
	public ResourceFoundException(String message) {
		super(message);
	}
}
