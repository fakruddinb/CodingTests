package com.genesis.core.domain.framework.exceptions;

public abstract class AbstractDomainEventHandlerException extends RuntimeException {
}
