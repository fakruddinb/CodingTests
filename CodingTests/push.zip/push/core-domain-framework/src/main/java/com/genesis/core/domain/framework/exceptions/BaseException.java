package com.genesis.core.domain.framework.exceptions;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class BaseException extends RuntimeException {
	
	private static final long serialVersionUID = 6177312724928007333L;

	private String errorCode;
	
	public BaseException(String errorCode, String message) {
		super(message);
		this.errorCode = errorCode;
	}
	
	public BaseException(String message) {
		super(message);
	}
	
}
