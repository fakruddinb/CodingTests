package com.genesis.core.domain.framework.domain;

import java.io.Serializable;

import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DomainId implements Serializable {
	
	private static final long serialVersionUID = 507327909704542543L;
	@Id
	private String id;
	
//	@Version
//	private int verion;

}