package com.genesis.core.domain.framework.utils;

public class KeyspaceConstants {
    /**
     * Keyspace names for the {@link com.genesis.core.domain.participant.domain.ta.demo.common.domain.model.Email} 
     * {@link com.genesis.core.domain.participant.domain.ta.demo.common.domain.model.Plan} {@link com.genesis.core.domain.participant.domain.ta.demo.common.domain.model.Phone}
     * {@link com.genesis.core.domain.participant.domain.ta.demo.common.domain.model.Participant} and {@link com.genesis.core.domain.participant.domain.ta.demo.common.domain.model.AchTransfer}
     * domain objects. These keyspaces are stored in Hazelcast
     * {@link com.hazelcast.core.IMap} maps with the same name.
     *
     * If a name is not given to the keyspace, it will default
     * to the full class name of the domain object.
     */
    public static final String PARTICIPANT         = "Participant";
    public static final String PARTICIPANT_PLAN    = "ParticipantPlan";
    public static final String EMAIL               = "Email";
    public static final String PHONE 	           = "Phone";
    public static final String PLAN 	           = "Plan";
    public static final String BENEFICIARY         = "Beneficiary";
    public static final String VESTING             = "Vesting";
    public static final String HOURS_WORKED        = "HoursWorked";
    public static final String EMPLOYMENT          = "Employment";
    public static final String ELIGIBILITY         = "Eligibility";
    public static final String EDELIVERY           = "EDelivery";
    public static final String CONTRIBUTIONS       = "Contributions";
    public static final String CONTRIBUTION_BUCKET = "ContributionBucket";
    public static final String COMPENSATION        = "Compensation";
    public static final String ACCOUNT_BALANCE     = "AccountBalance";
    public static final String BALANCE             = "Balance";
    public static final String ADDRESS             = "Address";
    public static final String ALLOCATION          = "Allocation";
    public static final String ACH_TRANSFER        = "Ach";
    public static final String AUTO_ENROLLMENT     = "AutoEnrollment";
    public static final String CALCULATION_INFORMATION = "CalculationInformation";
    public static final String YEAROFSERVICERULES = "YearOfServiceRules";
    public static final String YEARLYELIGIBILITYRULE = "YearlyEligibilityRule";
    public static final String VESTING_RULES = "VestingRules";
    public static final String SPONSOR =  "Sponsor";
    public static final String SHORTPLANDATE = "ShortPlanDate";
    public static final String PLAN_TYPE= "PlanType";
    public static final String RETIREMENT_PROVISIONS = "RetirementProvisions";
    public static final String PLAN_SOURCE = "PlanSource";
    public static final String PLAN_PROVISIONS = "PlanProvisions";
    public static final String PLAN_FUND = "PlanFund";
    public static final String PLAN_ELIGIBILITY = "PlanEligibility";
    public static final String PLAN_DATES = "PlanDates";
    public static final String PLAN_CLASS = "PlanClass";
    public static final String PLAN_ADMINSTRATOR = "PlanAdminstrator";
    
    public static final String FORMULA_OPTION = "FormulaOption";
    public static final String CONTRACT_SERVICE = "ContractService";

    public static final String ELIGIBILITY_CONTRIBUTION = "EligibilityContribution";
    
    public static final String PARTNER = "Partner";
    public static final String PLAN_ACH = "PlanAch";
    
}
