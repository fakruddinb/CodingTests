package com.genesis.core.domain.framework.model;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@RequiredArgsConstructor
public class ResponseModel {

    @Schema(description = "The response needed to access/show in case of the error ")
    private final String response;

    @Schema(description = "The httpstatus of the error ")
    private final HttpStatus status;

    @Schema(description = "The time of error accrued")
    private final LocalDateTime date;

    @Schema(description = "The error code refers for the localisation, e.g. '001- Projects not found'")
    private final String code;

    @Schema(description = "A human readable error message")
    private final String message;

}
