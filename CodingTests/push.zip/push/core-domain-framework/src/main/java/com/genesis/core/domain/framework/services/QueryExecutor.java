package com.genesis.core.domain.framework.predicateQuery;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;
import com.hazelcast.query.Predicates;
import com.hazelcast.sql.SqlColumnMetadata;
import com.hazelcast.sql.SqlResult;
import com.hazelcast.sql.SqlStatement;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class QueryExecutor implements SQLQueries {

	private static final long serialVersionUID = 1L;
	private final HazelcastInstance hazelcastInstance;

	/**
	 * To get the results across maps using the Sql style queries and list of arguments
	 * 
	 * @param sql - the Sql style query, with ? as arguments
	 *  - Example SELECT * FROM ParticipantMap mp, EmailMap ep where ep.pptId = mp.pptid and  mp.emailType = ? 
	 * @param args - The list of argument objects
	 * @return - List of Map objects - column with name and values
	 */
	@Override
	public Collection<?> executeSqlQueryOnAcrossMap(String sql, List<Object> args) {
		SqlStatement sqlStatement = new SqlStatement(sql);
		sqlStatement.setParameters(args);
		SqlResult sqlResult =  hazelcastInstance.getSql().execute(sqlStatement);
		Collection<Map<String, Object>> rows = new ArrayList<>();
		sqlResult.forEach(row ->{
			List<SqlColumnMetadata> columns = row.getMetadata().getColumns();
			Map<String, Object> mapCol = new HashMap<>();
			columns.forEach(col -> {
				mapCol.put(col.getName(), row.getObject(col.getName()));
			});
			rows.add(mapCol);
		});
		return rows;
	}

	/**
	 * To get the results from the HazelCast Map with required where clause
	 *  - Where clause or search criteria should match the attributes of the Map
	 * 
	 * @param sql - for Example "active AND (age > 20 OR salary < 60000)"
	 * @param mapKey - Map Key on which this query to be applied
	 * @return Collection of Results
	 */
	@Override
	public Collection<?> executeSqlQueryOnMap(String sql, String mapKey) {

		IMap<?, ?> map = hazelcastInstance.getMap(mapKey);
		return map.values(Predicates.sql(sql));
	}

}
