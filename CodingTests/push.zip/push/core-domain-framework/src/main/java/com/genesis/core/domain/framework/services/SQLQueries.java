package com.genesis.core.domain.framework.predicateQuery;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

/**
 * Interface for a SQLQueries that returns collections
 *
 */
public interface SQLQueries extends Serializable {

  Collection<?> executeSqlQueryOnMap(String mapName, String sSql);
  
  Collection<?> executeSqlQueryOnAcrossMap(String sSql, List<Object> args);
  
}
