package com.genesis.core.domain.framework.distributedObject;

import com.genesis.core.domain.framework.predicateQuery.PredicateQuery;

import java.util.Collection;
import java.util.stream.Stream;

public interface DistributedSetObject<T, P extends PredicateQuery<T>> {
  Boolean add(T value);
  Boolean addAll(Collection<? extends T> values);
  Boolean remove(T value);
  Boolean removeAll(Collection<? extends T> values);

  Stream<T> getValuesAsStream();

  Stream<T> queryValuesAsStream(P query);
}
