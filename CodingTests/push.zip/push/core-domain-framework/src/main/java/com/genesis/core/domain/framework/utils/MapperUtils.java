package com.genesis.core.domain.framework.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.genesis.core.domain.framework.domain.DomainId;
import com.github.fge.jsonpatch.JsonPatch;
import com.github.fge.jsonpatch.JsonPatchException;
import lombok.RequiredArgsConstructor;
import org.modelmapper.AbstractCondition;
import org.modelmapper.Condition;
import org.modelmapper.ModelMapper;
import org.modelmapper.spi.MappingContext;
import org.springframework.stereotype.Component;

import javax.validation.*;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class MapperUtils {
	private static ModelMapper modelMapper = null;
	private static ObjectMapper objectMapper = null;

	public <S, T> List<T> mapList(List<S> source, Class<T> targetClass) {
		return source.stream().map(element -> getModelMapper().map(element, targetClass)).collect(Collectors.toList());
	}

	public <T> T mapObject(Object source, Class<T> targetClass) {
		return source != null ? getModelMapper().map(source, targetClass) : null;
	}

	public <T extends DomainId> T mapObjectWithUUID(Object source, Class<T> targetClass) {
		T t = source != null ? getModelMapper().map(source, targetClass) : null;
		if (t != null) {
			t.setId(CommonUtils.getUUIDString());
		}
		return t;
	}

	public <T extends DomainId> T mapObject(UUID id, Object source, Class<T> targetClass) {
		T t = source != null ? getModelMapper().map(source, targetClass) : null;

		return t;
	}

	Condition<?, ?> isStringBlank = new AbstractCondition<Object, Object>() {
		@Override
		public boolean applies(MappingContext<Object, Object> context) {
			if (context.getSource() instanceof String) {
				return null != context.getSource() && !"".equals(context.getSource());
			} else {
				return context.getSource() != null;
			}
		}
	};

	public ModelMapper getModelMapper() {
		return (modelMapper == null) ? modelMapper = getModelMapperNewObject() : modelMapper;
	}

	public ModelMapper getModelMapperNewObject() {
		ModelMapper modelMapper = new ModelMapper();
		modelMapper.getConfiguration().setFieldMatchingEnabled(true).setAmbiguityIgnored(true)
				.setFieldAccessLevel(org.modelmapper.config.Configuration.AccessLevel.PRIVATE)
				.setPropertyCondition(isStringBlank).setSkipNullEnabled(true);
		return modelMapper;
	}

	public ObjectMapper getObjectMapper() {
		if (objectMapper == null) {
			objectMapper = JsonMapper.builder().findAndAddModules().build();
		}
		return objectMapper;
	}

	public <E, C> C applyPatchToModelNoValidation(JsonPatch patch, E target, Class<C> targetClass)
			throws JsonPatchException, JsonProcessingException {
		JsonNode patched = patch.apply(getObjectMapper().convertValue(target, JsonNode.class));
		C patchedTarget = getObjectMapper().treeToValue(patched, targetClass);
		return patchedTarget;
	}

	public <E, C> C applyPatchToModel(JsonPatch patch, E target, Class<C> targetClass)
			throws JsonPatchException, JsonProcessingException {
		JsonNode patched = patch.apply(getObjectMapper().convertValue(target, JsonNode.class));
		C patchedTarget = getObjectMapper().treeToValue(patched, targetClass);
		validateModel(patchedTarget);
		return patchedTarget;
	}

	public <M> void validateModel(M model) throws ConstraintViolationException {
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<M>> violations = validator.validate(model);
		if (!violations.isEmpty()) {
			throw new ConstraintViolationException(violations);
		}
	}

}
