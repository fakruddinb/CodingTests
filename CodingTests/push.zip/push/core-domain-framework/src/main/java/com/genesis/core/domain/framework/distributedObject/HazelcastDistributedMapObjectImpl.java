package com.genesis.core.domain.framework.distributedObject;

import com.genesis.core.domain.framework.cache.HazelcastCacheImpl;
import com.genesis.core.domain.framework.predicateQuery.AbstractHazelcastBiPredicateQuery;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;
import com.hazelcast.query.Predicates;

import org.assertj.core.util.Lists;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

public final class HazelcastDistributedMapObjectImpl<K, V> implements DistributedMapObject<K, V, AbstractHazelcastBiPredicateQuery<K, V>> {
  private final IMap<K, V> map;

  public HazelcastDistributedMapObjectImpl(
      HazelcastInstance cacheInstance,
      String mapName
  ) {
    this.map = cacheInstance.getMap(mapName);
  }

  public HazelcastDistributedMapObjectImpl(
      HazelcastCacheImpl cacheInstance,
      String mapName
  ) {
    this.map = cacheInstance.getCacheInstance().getMap(mapName);
  }

  @Override
  public CompletableFuture<V> saveAsync(K key, V value) {
    return this.map.putAsync(key, value).toCompletableFuture();
  }

  @Override
  public V save(K key, V value) {
    return this.map.put(key, value);
  }

  @Override
  public void saveAll(Map<K, V> values) {
    this.map.putAll(values);
  }

  @Override
  public CompletableFuture<V> getAsync(K key) {
    return this.map.getAsync(key).toCompletableFuture();
  }

  @Override
  public V get(K key) {
    return this.map.get(key);
  }

  @Override
  public CompletableFuture<V> removeAsync(K key) {
    return this.map.removeAsync(key).toCompletableFuture();
  }

  @Override
  public V remove(K key) {
    return this.map.remove(key);
  }

  @Override
  public void removeAll(List<K> keys) {
    this.map.clear();
  }

  @Override
  public void removeIf(AbstractHazelcastBiPredicateQuery<K, V> query) {
    this.map.removeAll(query);
  }

  @Override
  public Set<K> getKeysAsSet() {
    return this.map.keySet();
  }

  @Override
  public List<V> getValuesAsList() {
    return Lists.newArrayList(this.map.values());
  }

  @Override
  public Set<Map.Entry<K, V>> queryEntriesAsSet(AbstractHazelcastBiPredicateQuery<K, V> query) {
    return this.map.entrySet(query);
  }
  
  @Override
  public Collection<V> getByQuery(String query) {
    return this.map.values(Predicates.sql(query));
  }

}
