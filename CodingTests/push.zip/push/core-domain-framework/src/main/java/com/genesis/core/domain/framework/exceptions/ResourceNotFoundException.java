package com.genesis.core.domain.framework.exceptions;

public class ResourceNotFoundException extends BaseException {

	private static final long serialVersionUID = 5619738500140887135L;

	public ResourceNotFoundException(String message) {
		super(message);
	}
	
	public ResourceNotFoundException(String errorCode, String message) {
		super(message, errorCode);
	}

}
