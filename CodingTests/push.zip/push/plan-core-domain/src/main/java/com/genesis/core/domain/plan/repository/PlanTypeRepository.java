package com.genesis.core.domain.plan.repository;



import org.springframework.data.repository.CrudRepository;

import com.genesis.core.domain.plan.domain.PlanType;

public interface PlanTypeRepository extends CrudRepository<PlanType, String> {
	
   

}
