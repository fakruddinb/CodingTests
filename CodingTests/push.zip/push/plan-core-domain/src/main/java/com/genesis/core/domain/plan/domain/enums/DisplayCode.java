package com.genesis.core.domain.plan.domain.enums;

public enum DisplayCode {
	
	DISPLAY('Y'), 
	DO_NOT_DISPLAY('N');

	private char p3Code;
	
	DisplayCode(char p3Code){
		this.p3Code = p3Code;
	}
	
	public char getP3code() {
		return this.p3Code;
	}

}
