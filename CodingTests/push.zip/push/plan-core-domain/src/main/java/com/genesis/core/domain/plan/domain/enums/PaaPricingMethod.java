package com.genesis.core.domain.plan.domain.enums;

public enum PaaPricingMethod {
	
	CLIENT_COMPANY(1),
	AGGREGATE(2);
	
	private int p3Code;
	
	PaaPricingMethod(int p3Code){
		this.p3Code = p3Code;
	}
	
	public int getP3code() {
		return this.p3Code;
	}

}
