package com.genesis.core.domain.plan.domain;



import org.springframework.data.keyvalue.annotation.KeySpace;

import com.genesis.core.domain.framework.domain.DomainId;
import com.genesis.core.domain.framework.utils.KeyspaceConstants;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@KeySpace(KeyspaceConstants.PLAN_PROVISIONS)
public class PlanProvisions extends DomainId {

	private static final long serialVersionUID = -8127438640983049284L;
	private String planId;
	private	Boolean	loansPermitted;
	private	Boolean	inServiceWithdrawalsPermitted;
	private	Boolean	hardshipWithdrawalsPermitted;
	private	Boolean	multipleInserviceWDTypesAllowed;
	private	Boolean	isManagedAdvise;
	
	public PlanProvisions(String id, String planId, Boolean loansPermitted, Boolean inServiceWithdrawalsPermitted,
			Boolean hardshipWithdrawalsPermitted, Boolean multipleInserviceWDTypesAllowed, Boolean isManagedAdvise) {
		super(id);
		this.planId = planId;
		this.loansPermitted = loansPermitted;
		this.inServiceWithdrawalsPermitted = inServiceWithdrawalsPermitted;
		this.hardshipWithdrawalsPermitted = hardshipWithdrawalsPermitted;
		this.multipleInserviceWDTypesAllowed = multipleInserviceWDTypesAllowed;
		this.isManagedAdvise = isManagedAdvise;
	}
	
}
