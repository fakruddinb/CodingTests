package com.genesis.core.domain.plan.domain.enums;

public enum PaaType {
	
	MEP_PEO_MSO(1),
	MEP_ASSOC(2),
	MEP_NCC(3),
	ASO(4),
	OPEN_MEP(5),
	EXCHANGE(6),
	PEP(7),
	TAFT_HARTLEY(8);
	
	
	private int p3Code;
	
	PaaType(int p3Code){
		this.p3Code = p3Code;
	}
	
	public int getP3code() {
		return this.p3Code;
	}

}
