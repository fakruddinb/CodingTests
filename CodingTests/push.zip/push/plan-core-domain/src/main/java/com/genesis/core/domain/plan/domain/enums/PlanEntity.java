package com.genesis.core.domain.plan.domain.enums;

public enum PlanEntity {
	
	SINGLE_EMPLOYER_PLAN(0),
	CONTROLEED_GROUP(1),
	MULTIPLE_ER_PLAN(3),
	MULTI_ER(4),
	MULTI_ER_PLAN_OTHER(5);
	
	private int p3Code;
	
	PlanEntity(int p3Code){
		this.p3Code = p3Code;
	}
	
	public int getP3code() {
		return this.p3Code;
	}

}
