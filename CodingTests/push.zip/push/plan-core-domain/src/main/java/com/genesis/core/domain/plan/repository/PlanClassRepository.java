package com.genesis.core.domain.plan.repository;

import java.util.List;


import org.springframework.data.repository.CrudRepository;
import com.genesis.core.domain.plan.domain.PlanClass;

public interface PlanClassRepository extends CrudRepository<PlanClass, String> {
	
	List<PlanClass> findByPlanId(String planId);

}
