package com.genesis.core.domain.plan.repository;



import org.springframework.data.repository.CrudRepository;

import com.genesis.core.domain.plan.domain.FormulaOption;

public interface FormulaOptionRepository extends CrudRepository<FormulaOption, String> {
	
   

}
