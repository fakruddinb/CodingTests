package com.genesis.core.domain.plan.domain.enums;

public enum ServiceReqCode {

	NO_SERVICE(0), 
	XX_MONTHS(1), 
	ONE_YEAR_OF_SERVICE(2), 
	TWO_YEAR_OF_SERVICE(3),
	EXPECTED_YEAR_OF_SERVICE_ENTRY_AFTER_XX_MONTHS_OF_ACTUAL_SERVICE(4),
	COMPLETION_OF_X_HOURS_OF_SERVICE_WITHIN_XX_MONTHS_OF_EMPLOYMENT(5), 
	OTHER(6), 
	XX_DAYS(7), 
	XX_HOURS_OF_SERVICE_WITHIN_XX_MONTHS_SWITCHING_TO_1_YEAR_OF_SERVICE(8);

	private Integer p3Code;

	ServiceReqCode(Integer p3Code) {
		this.p3Code = p3Code;
	}

	public Integer getP3Code() {
		return p3Code;
	}
}
