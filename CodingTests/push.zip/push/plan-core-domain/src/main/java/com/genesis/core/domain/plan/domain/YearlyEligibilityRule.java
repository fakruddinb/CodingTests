package com.genesis.core.domain.plan.domain;



import org.springframework.data.keyvalue.annotation.KeySpace;

import com.genesis.core.domain.framework.domain.DomainId;
import com.genesis.core.domain.framework.utils.KeyspaceConstants;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@KeySpace(KeyspaceConstants.YEARLYELIGIBILITYRULE)
public class YearlyEligibilityRule extends DomainId {

	private static final long serialVersionUID = -6468981942760610754L;
	private String planEligibilityId;
	private Boolean isElapseTimeIndCode;
	private Integer elapseTimeMonthNo;
	private Boolean isDeathEligReqCode;
	private String yearlyEligText;
	private String yearlyHrsReqInd;
	
	public YearlyEligibilityRule(String id, String planEligibilityId, Boolean isElapseTimeIndCode, Integer elapseTimeMonthNo,
			Boolean isDeathEligReqCode, String yearlyEligText, String yearlyHrsReqInd) {
		super(id);
		this.planEligibilityId = planEligibilityId;
		this.isElapseTimeIndCode = isElapseTimeIndCode;
		this.elapseTimeMonthNo = elapseTimeMonthNo;
		this.isDeathEligReqCode = isDeathEligReqCode;
		this.yearlyEligText = yearlyEligText;
		this.yearlyHrsReqInd = yearlyHrsReqInd;
	}
	
	

}
