package com.genesis.core.domain.plan.domain;



import org.springframework.data.keyvalue.annotation.KeySpace;

import com.genesis.core.domain.framework.domain.DomainId;
import com.genesis.core.domain.framework.utils.KeyspaceConstants;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@KeySpace(KeyspaceConstants.VESTING_RULES)
public class VestingRules extends DomainId {

	private static final long serialVersionUID = -5611634245306331965L;

	private String planId;
	private Long vestingSchdId;
	private String vestingSchdTypCd;
	private Long vestingSchdPriorToYear;
	private Integer forfeitureAllocCd;
	private String reportSourceNm;
	private String vestingCompPeriod;
	private String forfAdoptEmpCd;
	private Integer ForfYrsPerCd;
	private Integer reinstYrsOfServCd;
	private String approvalCode;
	private Integer priorServCounted;
	private String rehireTrackCd;
	private String vestingYrOfServCd;
	private String actualEquivCd;
	private Integer vestYearHrsCt;
	private Integer equivVestCd;
	private String equivVestPerCd;
	private Integer roundingMoNo;
	private String servDisregardCd;
	private String servRecognizedCd;
	private String priorPlanInclCd;
	private Integer priorPlanYearsN;
	private String priorPlanT;
	private String eligIndCd;
	private String allocAccrualIndCd;
	private String vestIndCd;
	private String forfDistForTremCd;
	private String forfDistForRetCd;
	private String forfDistForDeathCd;
	private String forfDistFundsCd;
	private String forfDistForDisabCd;
	private Integer applVestTypCd;
	private Integer allocTimingCd;

}
