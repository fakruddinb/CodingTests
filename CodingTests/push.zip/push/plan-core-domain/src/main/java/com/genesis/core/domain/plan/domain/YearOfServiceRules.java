package com.genesis.core.domain.plan.domain;



import org.springframework.data.keyvalue.annotation.KeySpace;

import com.genesis.core.domain.framework.domain.DomainId;
import com.genesis.core.domain.framework.utils.KeyspaceConstants;
import com.genesis.core.domain.plan.domain.enums.EquivalencyCode;
import com.genesis.core.domain.plan.domain.enums.MinAgeCode;
import com.genesis.core.domain.plan.domain.enums.ServiceReqCode;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@KeySpace(KeyspaceConstants.YEAROFSERVICERULES)
public class YearOfServiceRules extends DomainId {
	
	private static final long serialVersionUID = -601771833221992956L;
	private String planEligibilityId;
	private Boolean isDefaultRuleIndCode;
	private MinAgeCode minAgeCode;
	private ServiceReqCode servReqCode;
	private EquivalencyCode equivalencyCode;
	private Integer yearlyHrsReqCount;
	private Integer rulesS;
	private String equivalencyPeriodCode;
	private Integer equivalencyHrsCount;
	
	public YearOfServiceRules(String id, String planEligibilityId, Boolean isDefaultRuleIndCode, MinAgeCode minAgeCode,
			ServiceReqCode servReqCode, EquivalencyCode equivalencyCode, Integer yearlyHrsReqCount, Integer rulesS,
			String equivalencyPeriodCode, Integer equivalencyHrsCount) {
		super(id);
		this.planEligibilityId = planEligibilityId;
		this.isDefaultRuleIndCode = isDefaultRuleIndCode;
		this.minAgeCode = minAgeCode;
		this.servReqCode = servReqCode;
		this.equivalencyCode = equivalencyCode;
		this.yearlyHrsReqCount = yearlyHrsReqCount;
		this.rulesS = rulesS;
		this.equivalencyPeriodCode = equivalencyPeriodCode;
		this.equivalencyHrsCount = equivalencyHrsCount;
	}
	
	


}
