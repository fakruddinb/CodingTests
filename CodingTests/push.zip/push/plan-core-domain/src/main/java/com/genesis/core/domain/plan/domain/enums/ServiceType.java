package com.genesis.core.domain.plan.domain.enums;

public enum ServiceType {
	
	FULL_SERVICE(1),
	RECORD_KEEPING(2);
	
	private int p3Code;
	
	ServiceType(int p3Code){
		this.p3Code = p3Code;
	}
	
	public int getP3code() {
		return this.p3Code;
	}

}
