package com.genesis.core.domain.plan.domain.enums;

public enum EntryDateCode {
	
	FIRST_OF_THE_MONTH_CONICIDING_WITH_OE_FOLLOWING(0), 
	FIRST_DAY_OFFIRST_FULL_PAYROLL_PERIOD(1),
	FIRST_DAY_OF_THEPLAN_YEAR_QUARTER_ON_OR_NEXT_FOLLOWING_DATE_REQUIREMENTS_MET(2),
	SEMI_ANNUALLY(3), 
	EMPLOYEE_DATE_OF_HIRE(4),
	FIRST_DAY_OF_THE_PLAN_YEAR_ON_OR_NEXT_FOLLOWING_DATE_REQUIREMENTS_ARE_MET(5);

	private Integer p3Code;

	EntryDateCode(Integer p3Code) {
		this.p3Code = p3Code;
	}

	public Integer getP3Code() {
		return p3Code;
	}

}
