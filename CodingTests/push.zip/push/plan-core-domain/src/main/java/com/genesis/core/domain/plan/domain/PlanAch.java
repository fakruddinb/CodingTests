package com.genesis.core.domain.plan.domain;

import java.time.LocalDate;


import org.springframework.data.keyvalue.annotation.KeySpace;

import com.genesis.core.domain.framework.domain.DomainId;
import com.genesis.core.domain.framework.utils.KeyspaceConstants;
import com.genesis.core.domain.plan.domain.enums.AccountStatusType;
import com.genesis.core.domain.plan.domain.enums.BankAccountType;
import com.genesis.core.domain.plan.domain.enums.RddTypeCode;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@KeySpace(KeyspaceConstants.PLAN_ACH)
public class PlanAch extends DomainId {
	
	private static final long serialVersionUID = -4159888723776152727L;
	private String planId;
	private Integer abaSequanceId;
	private String routingNo;
	private String bankAccountNo;
	private BankAccountType accountType;
	private String bankName;
	private String nickName;
	private LocalDate effectiveDate;
	private AccountStatusType accountStatus;
	private RddTypeCode rddTypeCode;
	
	public PlanAch(String id, String planId, Integer abaSequanceId, String routingNo, String bankAccountNo,
			BankAccountType accountType, String bankName, String nickName, LocalDate effectiveDate,
			AccountStatusType accountStatus, RddTypeCode rddTypeCode) {
		super(id);
		this.planId = planId;
		this.abaSequanceId = abaSequanceId;
		this.routingNo = routingNo;
		this.bankAccountNo = bankAccountNo;
		this.accountType = accountType;
		this.bankName = bankName;
		this.nickName = nickName;
		this.effectiveDate = effectiveDate;
		this.accountStatus = accountStatus;
		this.rddTypeCode = rddTypeCode;
	}
	
	

}
