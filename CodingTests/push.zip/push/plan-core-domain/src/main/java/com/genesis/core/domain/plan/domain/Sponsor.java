package com.genesis.core.domain.plan.domain;



import org.springframework.data.keyvalue.annotation.KeySpace;

import com.genesis.core.domain.framework.domain.DomainId;
import com.genesis.core.domain.framework.utils.KeyspaceConstants;
import com.genesis.core.domain.plan.domain.enums.ChurchPlanEntityType;
import com.genesis.core.domain.plan.domain.enums.Classification;
import com.genesis.core.domain.plan.domain.enums.EntityOfPlanSponsor;
import com.genesis.core.domain.plan.domain.enums.IRSBusinessTaxCode;
import com.genesis.core.domain.plan.domain.enums.PlanEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@KeySpace(KeyspaceConstants.SPONSOR)
public class Sponsor extends DomainId {
	
	private static final long serialVersionUID = 2479471324983404677L;

	private String planId;
	private EntityOfPlanSponsor entityofPlanSponsor;
	private String controlledGroupName;
	private PlanEntity planEntity;
	private String planSponsorIdentification;
	private IRSBusinessTaxCode irsBusinessTaxCode;
	private Classification classisication;
	private String isThePlanPubliclyTraded;
	private ChurchPlanEntityType churchPlanEntityType;
	
	public Sponsor(String id, String planId, EntityOfPlanSponsor entityofPlanSponsor, String controlledGroupName,
			PlanEntity planEntity, String planSponsorIdentification, IRSBusinessTaxCode irsBusinessTaxCode,
			Classification classisication, String isThePlanPubliclyTraded, ChurchPlanEntityType churchPlanEntityType) {
		super(id);
		this.planId = planId;
		this.entityofPlanSponsor = entityofPlanSponsor;
		this.controlledGroupName = controlledGroupName;
		this.planEntity = planEntity;
		this.planSponsorIdentification = planSponsorIdentification;
		this.irsBusinessTaxCode = irsBusinessTaxCode;
		this.classisication = classisication;
		this.isThePlanPubliclyTraded = isThePlanPubliclyTraded;
		this.churchPlanEntityType = churchPlanEntityType;
	}

    

}
