package com.genesis.core.domain.plan.domain;



import org.springframework.data.keyvalue.annotation.KeySpace;

import com.genesis.core.domain.framework.domain.DomainId;
import com.genesis.core.domain.framework.utils.KeyspaceConstants;
import com.genesis.core.domain.plan.domain.enums.PeriodOfServiceDefinition;
import com.genesis.core.domain.plan.domain.enums.PeriodsofServiceMeans;
import com.genesis.core.domain.plan.domain.enums.RetirementDate;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@KeySpace(KeyspaceConstants.RETIREMENT_PROVISIONS)
public class RetirementProvisions extends DomainId {
	
    private static final long serialVersionUID = -2824763858660566526L;

	private String planId;
	private int normalRetirementAge;
	private RetirementDate normalRetirementDate;
	private String  normalRetirementOther;
	private int normalRetirementYearsOfService;
	private int earlyRetirementAge;
	private int earlyRetirementYearsOfService;
	private PeriodsofServiceMeans earlyRetirementPeriodsofServiceMeans;
	private PeriodOfServiceDefinition earlyRetirementPeriodofServiceDefinition403b;
	private RetirementDate earlyRetirementDate;
	private String  earlyRetirementOther;
	private String earlyRetirementPlanVests100PercentAtEarlyRetirement;
	
	public RetirementProvisions(String id, String planId, int normalRetirementAge, RetirementDate normalRetirementDate,
			String normalRetirementOther, int normalRetirementYearsOfService, int earlyRetirementAge,
			int earlyRetirementYearsOfService, PeriodsofServiceMeans earlyRetirementPeriodsofServiceMeans,
			PeriodOfServiceDefinition earlyRetirementPeriodofServiceDefinition403b, RetirementDate earlyRetirementDate,
			String earlyRetirementOther, String earlyRetirementPlanVests100PercentAtEarlyRetirement) {
		super(id);
		this.planId = planId;
		this.normalRetirementAge = normalRetirementAge;
		this.normalRetirementDate = normalRetirementDate;
		this.normalRetirementOther = normalRetirementOther;
		this.normalRetirementYearsOfService = normalRetirementYearsOfService;
		this.earlyRetirementAge = earlyRetirementAge;
		this.earlyRetirementYearsOfService = earlyRetirementYearsOfService;
		this.earlyRetirementPeriodsofServiceMeans = earlyRetirementPeriodsofServiceMeans;
		this.earlyRetirementPeriodofServiceDefinition403b = earlyRetirementPeriodofServiceDefinition403b;
		this.earlyRetirementDate = earlyRetirementDate;
		this.earlyRetirementOther = earlyRetirementOther;
		this.earlyRetirementPlanVests100PercentAtEarlyRetirement = earlyRetirementPlanVests100PercentAtEarlyRetirement;
	}
	
	
	

}
