package com.genesis.core.domain.plan.repository;



import org.springframework.data.repository.CrudRepository;

import com.genesis.core.domain.plan.domain.PlanDates;

public interface PlanDateRepository extends CrudRepository<PlanDates, String> {
	
   

}
