package com.genesis.core.domain.plan.domain.enums;

public enum ClassTypeCode {

	DEFAULT_CLASSES(0), 
	ACCOUNT_SPECIFIC_CLASSES(1);

	private Integer p3Code;

	ClassTypeCode(Integer p3Code) {
		this.p3Code = p3Code;
	}

	public Integer getP3Code() {
		return p3Code;
	}

}
