package com.genesis.core.domain.plan.domain.enums;

public enum Segmentation {
	
	MID_MARKET(1),
	LARGE_MARKET(3),
	MEGA_MARKET(4),
	NA(9);
	
	private int p3Code;
	
	Segmentation(int p3Code){
		this.p3Code = p3Code;
	}
	
	public int getP3code() {
		return this.p3Code;
	}

}
