package com.genesis.core.domain.plan.domain;

import java.time.LocalDate;


import org.springframework.data.keyvalue.annotation.KeySpace;

import com.genesis.core.domain.framework.domain.DomainId;
import com.genesis.core.domain.framework.utils.KeyspaceConstants;
import com.genesis.core.domain.plan.domain.enums.BreakPeriodOfService;
import com.genesis.core.domain.plan.domain.enums.CompPerCode;
import com.genesis.core.domain.plan.domain.enums.DisplayContribCode;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@KeySpace(KeyspaceConstants.CALCULATION_INFORMATION)
public class EligibilityContribution extends DomainId {

	private static final long serialVersionUID = 4685365534740856768L;

	private String planEligibilityId;
	private CompPerCode compPerCode;
	private Boolean isIgnoreHoursRequirement;
	private BreakPeriodOfService breakPeriodOfService;
	private String rolloverContriCode;
	private Integer planFormerROContriCode;
	private LocalDate eligEfectivefDate;
	private Boolean isElectTransferPriorAllowCode;
	private Boolean isSpecialEligWaiverCode;
	private LocalDate employedOnWaiverDt;
	private DisplayContribCode displayContribCode;
	private Boolean isWaiverAmendedRestatedCode;
	
	public EligibilityContribution(String id, String planEligibilityId, CompPerCode compPerCode, Boolean isIgnoreHoursRequirement,
			BreakPeriodOfService breakPeriodOfService, String rolloverContriCode, Integer planFormerROContriCode,
			LocalDate eligEfectivefDate, Boolean isElectTransferPriorAllowCode, Boolean isSpecialEligWaiverCode,
			LocalDate employedOnWaiverDt, DisplayContribCode displayContribCode, Boolean isWaiverAmendedRestatedCode) {
		super(id);
		this.planEligibilityId = planEligibilityId;
		this.compPerCode = compPerCode;
		this.isIgnoreHoursRequirement = isIgnoreHoursRequirement;
		this.breakPeriodOfService = breakPeriodOfService;
		this.rolloverContriCode = rolloverContriCode;
		this.planFormerROContriCode = planFormerROContriCode;
		this.eligEfectivefDate = eligEfectivefDate;
		this.isElectTransferPriorAllowCode = isElectTransferPriorAllowCode;
		this.isSpecialEligWaiverCode = isSpecialEligWaiverCode;
		this.employedOnWaiverDt = employedOnWaiverDt;
		this.displayContribCode = displayContribCode;
		this.isWaiverAmendedRestatedCode = isWaiverAmendedRestatedCode;
	}
	
	
}
