package com.genesis.core.domain.plan.domain.enums;

public enum PriorCarrierPlantype {
	
	NA(0),
	DC_ONLY(1),
	TOTAL_BENEFIT_OUTSOURCED_PLAN(3),
	TOTAL_RETIREMENT_OUTSOURCED_PLAN(4),
	BPS_IMPACTED(5);
	
	private int p3Code;
	
	PriorCarrierPlantype(int p3Code){
		this.p3Code = p3Code;
	}
	
	public int getP3code() {
		return this.p3Code;
	}

}
