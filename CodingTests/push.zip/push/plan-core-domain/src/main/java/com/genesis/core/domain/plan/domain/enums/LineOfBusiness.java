package com.genesis.core.domain.plan.domain.enums;

public enum LineOfBusiness {
	TDA(1),
	CORP(2),
	IAG(3),
	AEGON(4),
	PENSION(5);
	
	private Integer p3Code;
	
	LineOfBusiness(Integer p3Code) {
		this.p3Code = p3Code;
	}

	public Integer getP3Code() {
		return p3Code;
	}
}
