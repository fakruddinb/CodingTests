package com.genesis.core.domain.plan.repository;



import org.springframework.data.repository.CrudRepository;

import com.genesis.core.domain.plan.domain.PlanEligibility;

public interface PlanEligibilityRepository extends CrudRepository<PlanEligibility, String> {
	
   

}
