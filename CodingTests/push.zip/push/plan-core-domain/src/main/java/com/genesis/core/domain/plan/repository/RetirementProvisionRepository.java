package com.genesis.core.domain.plan.repository;



import org.springframework.data.repository.CrudRepository;

import com.genesis.core.domain.plan.domain.RetirementProvisions;

public interface RetirementProvisionRepository extends CrudRepository<RetirementProvisions, String> {
	
   

}
