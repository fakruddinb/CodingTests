package com.genesis.core.domain.plan.domain.enums;

public enum DocumentType {
	
	PLAN_401K_VOLUME_SUBMITTER('2'),
	IDP('5'),
	OUTSIDE_PLAN('6'),
	PLAN_403B_VOLUME_SUBMITTER('Z'),
	PS_VOLUME_SUBMITTER('Y'),
	MP_VOLUME_SUBMITTER('X');
	
	private char p3Code;
	
	DocumentType(char p3Code){
		this.p3Code = p3Code;
	}
	
	public char getP3code() {
		return this.p3Code;
	}

}
