package com.genesis.core.domain.plan.domain.enums;

public enum RetirementDate {
	
	FOLLOWING_ANNIVERSERY(1),
	PRECEDING_ANNIVERSERY(2),
	NEAREST_ANNIVERSEY(3),
	FIRST_OF_MONTH_FOLLOWING_NORMAL_RETIREMENT_AGE(4),
	FIRST_OF_MONTH_PRECEDING_RETIREMENT_AGE(5);
	
	private int p3Code;
	
	RetirementDate(int p3Code){
		this.p3Code = p3Code;
	}
	
	public int getP3code() {
		return this.p3Code;
	}


}
