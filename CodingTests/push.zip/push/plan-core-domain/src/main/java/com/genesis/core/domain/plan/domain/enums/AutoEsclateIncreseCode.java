package com.genesis.core.domain.plan.domain.enums;

public enum AutoEsclateIncreseCode {
	
	FIRST_DAY_OF_THE_PLAN_YEAR(1),
	SPECIFIC_DATE_SET_BY_THE_PLAN_MM_DD(2), 
	ON_THE_PARTICIPANTS_ANNIVERSARY_OF_THEIR_INITIAL_AUTOMATIC_ENROLLMENT_DATE(3);
	
	private Integer p3Code;

	AutoEsclateIncreseCode(Integer p3Code) {
		this.p3Code = p3Code;
	}
	public Integer getP3Code() {
		return p3Code;
	}

}
