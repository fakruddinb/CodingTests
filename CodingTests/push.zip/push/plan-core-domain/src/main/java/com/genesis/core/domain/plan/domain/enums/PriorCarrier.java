package com.genesis.core.domain.plan.domain.enums;

public enum PriorCarrier {

	NA(0),
	MERCER(1),
	FIBI_PBS(2),
	PAYCHEX(3),
	ORIENTAL_PENSION(4),
	HOME_OFFICE(5);
	
	private int p3Code;
	
	PriorCarrier(int p3Code){
		this.p3Code = p3Code;
	}
	
	public int getP3code() {
		return this.p3Code;
	}

}
