package com.genesis.core.domain.plan.domain.enums;

public enum PlanTypeCode {
	
	MONEY_PURCHASE("00"),
	PROFIT_SHARING("01"),
	PLAN_401K("02"),
	PLAN_457B_GOVERNMENT("03"),
	CASH_BALANCE("05"),
	ESPO("09");
	
	private String p3Code;
	
	PlanTypeCode(String p3Code){
		this.p3Code = p3Code;
	}
	
	public String getP3code() {
		return this.p3Code;
	}

}
