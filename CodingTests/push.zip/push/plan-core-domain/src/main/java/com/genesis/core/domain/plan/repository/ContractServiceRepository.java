package com.genesis.core.domain.plan.repository;



import org.springframework.data.repository.CrudRepository;

import com.genesis.core.domain.plan.domain.ContractService;

public interface ContractServiceRepository extends CrudRepository<ContractService, String> {
	
   

}
