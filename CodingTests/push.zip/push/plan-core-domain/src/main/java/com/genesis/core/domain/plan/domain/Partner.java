package com.genesis.core.domain.plan.domain;



import org.springframework.data.keyvalue.annotation.KeySpace;

import com.genesis.core.domain.framework.domain.DomainId;
import com.genesis.core.domain.framework.utils.KeyspaceConstants;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@KeySpace(KeyspaceConstants.PARTNER)
public class Partner extends DomainId {

	private static final long serialVersionUID = -8043150568037956342L;
	private String planId;
	private int serviceModel;
	
	public Partner(String id, String planId, int serviceModel) {
		super(id);
		this.planId = planId;
		this.serviceModel = serviceModel;
	}
	
	

}
