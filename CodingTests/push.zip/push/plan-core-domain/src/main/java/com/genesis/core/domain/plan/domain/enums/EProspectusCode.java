package com.genesis.core.domain.plan.domain.enums;

public enum EProspectusCode {
	
	NONCONSENT_NO_PAPER_COPY_MAILED(1),
	CONSENT_PAPER_COPY_MAILED(2);
	
	private int p3Code;
	
	EProspectusCode(int p3Code){
		this.p3Code = p3Code;
	}
	
	public int getP3code() {
		return this.p3Code;
	}

}
