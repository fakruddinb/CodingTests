package com.genesis.core.domain.plan.domain.enums;

public enum DisplayContribCode {
	
	SELECTED_ON_PLAN(1), 
	ALL_CONTRIBUTIONS(2);

	private Integer p3Code;

	DisplayContribCode(Integer p3Code) {
		this.p3Code = p3Code;
	}
	public Integer getP3Code() {
		return p3Code;
	}

}
