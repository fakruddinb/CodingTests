package com.genesis.core.domain.plan.domain;

import com.genesis.core.domain.framework.domain.DomainId;
import com.genesis.core.domain.framework.utils.KeyspaceConstants;
import com.genesis.core.domain.plan.domain.enums.ClassCode;
import com.genesis.core.domain.plan.domain.enums.EntryDateCode;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.Set;


import org.springframework.data.keyvalue.annotation.KeySpace;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@KeySpace(KeyspaceConstants.PLAN_ELIGIBILITY)
public class PlanEligibility extends DomainId {

	private static final long serialVersionUID = 7175105428600375832L;
	private String planId;
	private String sourceType;
	private Integer sourceSequenceNumber;
	private String documentName;
	private String className;
	private ClassCode classCode;
	private String exclusionCode;
	private EntryDateCode entryDateCode;
	private Set<String> eligContributions = new HashSet<>();
	private Set<String> yearOfServiceRules = new HashSet<>();
	private Set<String> yearlyEligRules = new HashSet<>();


}
