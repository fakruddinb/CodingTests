package com.genesis.core.domain.plan.domain;

import java.time.LocalDate;


import org.springframework.data.keyvalue.annotation.KeySpace;

import com.genesis.core.domain.framework.domain.DomainId;
import com.genesis.core.domain.framework.utils.KeyspaceConstants;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@KeySpace(KeyspaceConstants.SHORTPLANDATE)
public class ShortPlanDate extends DomainId {

	private static final long serialVersionUID = -6024343764900684401L;
	private String planDatesId;
	private String shortPlanYear;
	private String yearToBeAdjusted;
	private String shortPlanYearEndDate;
	private String startDateofNewYear;
	private String tra86DeterminationLetterReceivedDate;
	private LocalDate gustDeterminationLetterReceivedDate;
	
	public ShortPlanDate(String id, String planDatesId, String shortPlanYear, String yearToBeAdjusted, String shortPlanYearEndDate,
			String startDateofNewYear, String tra86DeterminationLetterReceivedDate,
			LocalDate gustDeterminationLetterReceivedDate) {
		super(id);
		this.planDatesId = planDatesId;
		this.shortPlanYear = shortPlanYear;
		this.yearToBeAdjusted = yearToBeAdjusted;
		this.shortPlanYearEndDate = shortPlanYearEndDate;
		this.startDateofNewYear = startDateofNewYear;
		this.tra86DeterminationLetterReceivedDate = tra86DeterminationLetterReceivedDate;
		this.gustDeterminationLetterReceivedDate = gustDeterminationLetterReceivedDate;
	}

   
}
