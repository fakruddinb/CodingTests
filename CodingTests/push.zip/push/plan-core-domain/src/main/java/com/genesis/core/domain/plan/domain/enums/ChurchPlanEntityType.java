package com.genesis.core.domain.plan.domain.enums;

public enum ChurchPlanEntityType {
	
	NON_QCCO_TAX_EXMEPT_ENTITY_AFFLIATED_TO_CHURCH(1),
	CHURCH_OR_NON_QCCO_UNDER_SECTION_312_W_3(2);	
	
	private int p3Code;
	
	ChurchPlanEntityType(int p3Code){
		this.p3Code = p3Code;
	}
	
	public int getP3code() {
		return this.p3Code;
	}
}
