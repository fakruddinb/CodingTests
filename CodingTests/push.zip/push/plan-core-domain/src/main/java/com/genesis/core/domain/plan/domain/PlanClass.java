package com.genesis.core.domain.plan.domain;

import java.time.LocalDate;


import org.springframework.data.keyvalue.annotation.KeySpace;

import com.genesis.core.domain.framework.domain.DomainId;
import com.genesis.core.domain.framework.utils.KeyspaceConstants;
import com.genesis.core.domain.plan.domain.enums.ClassCode;
import com.genesis.core.domain.plan.domain.enums.ClassTypeCode;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@KeySpace(KeyspaceConstants.PLAN_CLASS)
public class PlanClass extends DomainId {

    private static final long serialVersionUID = -7557689682921586672L;
	private String planId;
	private Long classProvI;
	private Long classI;
	private ClassTypeCode classTypeCode;
	private String className;
	private ClassCode classCode;
	private String exclusionCode;
	private LocalDate effectiveDate;
	private String status;
	private String compPeriodCode;
	private String userId;
	private LocalDate creationTS;
	
	public PlanClass(String id,String planId,Long classProvI, Long classI, ClassTypeCode classTypeCode, String className,
			ClassCode classCode, String exclusionCode, LocalDate effectiveDate, String status, String compPeriodCode,
			String userId, LocalDate creationTS) {
		super(id);
		this.planId = planId;
		this.classProvI = classProvI;
		this.classI = classI;
		this.classTypeCode = classTypeCode;
		this.className = className;
		this.classCode = classCode;
		this.exclusionCode = exclusionCode;
		this.effectiveDate = effectiveDate;
		this.status = status;
		this.compPeriodCode = compPeriodCode;
		this.userId = userId;
		this.creationTS = creationTS;
	}
	
	


}
