package com.genesis.core.domain.plan.domain.enums;

public enum Classification {
	
	CORPORATE(1),
	SUBCHAPTER(2),
	HR_10(3),
	SELF_EMPLYED(4);
	
	private int p3Code;
	
	Classification(int p3Code){
		this.p3Code = p3Code;
	}
	
	public int getP3code() {
		return this.p3Code;
	}

}
