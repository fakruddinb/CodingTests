package com.genesis.core.domain.plan.domain.enums;

public enum DefaultGroupCode {
	NOT_DEFAULT(0),
	DEFAULT_PLAN_ENROLLMENT(1),
	DEFAULT_PARTICIPANT_ENROLLMENT(2),
	DEFAULT_FOR_BOTH(3);
	
	private Integer p3Code;
	
	DefaultGroupCode(Integer p3Code) {
		this.p3Code = p3Code;
	}

	public Integer getP3Code() {
		return p3Code;
	}
}
