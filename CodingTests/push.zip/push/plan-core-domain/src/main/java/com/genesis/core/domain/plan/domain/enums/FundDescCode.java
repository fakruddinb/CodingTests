package com.genesis.core.domain.plan.domain.enums;

public enum FundDescCode {
	
	Y3EH(1),
	N664(2),
	N125(3),
	Z038(4),
	CBLS(5),
	Y4NN(6),
	S444(8),
	S492(8),
	S493(9),
	Y6ET(10),
	VINX(11),
	VIII(12),
	VEMP(13),
	Y4NQ(14),
	VEMX(15),
	VBIT(16),
	VGAC(17),
	VBTI(18),
	VEIR(19),
	VIEI(20);
	private Integer p3Code;

	FundDescCode(Integer p3Code) {
		this.p3Code = p3Code;
	}
	public Integer getP3Code() {
		return p3Code;
	}

}
