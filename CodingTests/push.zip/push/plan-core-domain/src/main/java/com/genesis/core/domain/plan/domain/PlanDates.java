package com.genesis.core.domain.plan.domain;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;


import org.springframework.data.keyvalue.annotation.KeySpace;

import com.genesis.core.domain.framework.domain.DomainId;
import com.genesis.core.domain.framework.utils.KeyspaceConstants;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@KeySpace(KeyspaceConstants.PLAN_DATES)
public class PlanDates extends DomainId {

	private static final long serialVersionUID = -4028095267366339730L;
	private String planId;
	private String startDatewithTransamerica;
	private String planAnniversary;
	private String firstAnniversaryYearEndDate;
	private String originalPlanEffectiveDate;
	private LocalDate planRestatementDate;
	private Boolean isContractTermination;
	private String planTerminationDate;
	private String affiliateEffectiveDate;
	private LocalDate frozenPlanDate;
	private String planYearBeginDate;
	private String planYearEndDate;
	private LocalDate planLimitationYearBeginDate;
	private LocalDate planLimitationYearEndDate;
	private String planFiscalYear;
	private LocalDate billingTerminationDate;
	private String planPayoutDate;
	private String affiliateTerminationDate;
	
	private Set<ShortPlanDate> shortPlanDates = new HashSet<>();
	

}
