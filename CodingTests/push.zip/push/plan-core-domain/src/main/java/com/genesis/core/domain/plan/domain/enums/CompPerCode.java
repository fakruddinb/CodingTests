package com.genesis.core.domain.plan.domain.enums;

public enum CompPerCode {

	NA_ELAPSED_TIME(0), 
	PLAN_YEAR(1), 
	EMPLOYMENT_YEAR(2);

	private Integer p3Code;

	CompPerCode(Integer p3Code) {
		this.p3Code = p3Code;
	}

	public Integer getP3Code() {
		return p3Code;
	}
}
