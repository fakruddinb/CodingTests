package com.genesis.core.domain.plan.repository;



import org.springframework.data.repository.CrudRepository;

import com.genesis.core.domain.plan.domain.PlanAch;

public interface PlanACHRepository extends CrudRepository<PlanAch, String> {
	
   

}
