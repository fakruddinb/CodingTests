package com.genesis.core.domain.plan.domain;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.springframework.data.keyvalue.annotation.KeySpace;

import com.genesis.core.domain.framework.domain.DomainId;
import com.genesis.core.domain.framework.utils.KeyspaceConstants;
import com.genesis.core.domain.plan.domain.enums.ConversionStatusCode;
import com.genesis.core.domain.plan.domain.enums.DefaultGroupCode;
import com.genesis.core.domain.plan.domain.enums.EnrolmentStatusCode;
import com.genesis.core.domain.plan.domain.enums.LineOfBusiness;
import com.genesis.core.domain.plan.domain.enums.RelatedGroupTypeCode;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@KeySpace(KeyspaceConstants.PLAN)
public class Plan extends DomainId {

	private static final long serialVersionUID = -1746600566046038780L;
	private Long planEnrolId;
	private Long enrolProvGroupId;
	private DefaultGroupCode defaultGroupCode;
	private Long relatedGrpId;
	private RelatedGroupTypeCode relatedgGrpTypCode;
	private String provGrpSrchName;
	private String accountNo;
	private LineOfBusiness lineOfBusiness;
	private EnrolmentStatusCode enrolStatusCode;
	private ConversionStatusCode convStatusCode;
	private LocalDate conversionDate;
	private String planNameLine1;
	private String PlanNameLine2;
	private String planName;
	private BigDecimal accountBalance;
	
//	private Set<String> contractService = new HashSet<>();
//	private Set<String> partners = new HashSet<>();
//	private Set<String> sponsors = new HashSet<>();
//	private Set<String> planTypes = new HashSet<>();
//	private Set<String> planDates = new HashSet<>();
//	private Set<String> retirementProvisions = new HashSet<>();
//	private Set<String> planProvisions = new HashSet<>();
//
//	private Set<String> planSources = new HashSet<>();
//	private Set<String> planFunds = new HashSet<>();
//	private Set<String> planClasses = new HashSet<>();
//	private Set<String> planAchs = new HashSet<>();
//	private Set<String> planEligibilityList = new HashSet<>();
//	private Set<String> vestingRulesList = new HashSet<>();

	private String creationUserId;
	private LocalDate creationTS;
	

	
}
