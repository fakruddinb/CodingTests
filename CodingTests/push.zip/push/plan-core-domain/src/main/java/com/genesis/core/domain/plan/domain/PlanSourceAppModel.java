package com.genesis.core.domain.plan.domain;

import java.io.Serializable;

import lombok.Data;

@Data
public class PlanSourceAppModel implements Serializable{
	private static final long serialVersionUID = 3264471795949832492L;
	private String sourceId;
	private String sourceName;
	private boolean isAutoEscalate;
}
