package com.genesis.core.domain.plan.domain.enums;

public enum ContractIssuer {
	
	TLIC(1),
	TFLIC(2);
	
	private int p3Code;
	
	ContractIssuer(int p3Code){
		this.p3Code = p3Code;
	}
	
	public int getP3code() {
		return this.p3Code;
	}

}
