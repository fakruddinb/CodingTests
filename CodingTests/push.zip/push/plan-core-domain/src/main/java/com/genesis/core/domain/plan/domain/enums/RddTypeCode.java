package com.genesis.core.domain.plan.domain.enums;

public enum RddTypeCode {
	
	ACH('A'), 
	WIRE('W');

	private char p3Code;
	
	RddTypeCode(char p3Code){
		this.p3Code = p3Code;
	}
	
	public char getP3code() {
		return this.p3Code;
	}


}
