package com.genesis.core.domain.plan.domain.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum AccountStatusType {

    ONE_TIME("ONE_TIME"),
    ACTIVE("ACTIVE"),
    HISTORY("HISTORY");
    private String accountStatus;

}
