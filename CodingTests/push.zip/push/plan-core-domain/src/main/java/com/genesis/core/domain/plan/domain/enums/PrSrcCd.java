package com.genesis.core.domain.plan.domain.enums;
public enum PrSrcCd {

	EMPLOYER_NON_ELECTIVE(0), 
	UNCLAIMED_BENEFITS(1), 
	ROTH_CONTRIBUTION(2), 
	EMPLOYEE_VALUNTARY_AFTER_TAX(3),
	EMPLOYEE_PRE_TAX_DEFERRAL(4), 
	EMPLOYER_MATCH(5), 
	QUALIFIED_ER_NON_ELECTIVE(6);

	private Integer p3Code;

	PrSrcCd(Integer p3Code) {
		this.p3Code = p3Code;
	}

	public Integer getP3Code() {
		return p3Code;
	}

}
