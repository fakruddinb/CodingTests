package com.genesis.core.domain.plan.domain;



import org.springframework.data.keyvalue.annotation.KeySpace;

import com.genesis.core.domain.framework.domain.DomainId;
import com.genesis.core.domain.framework.utils.KeyspaceConstants;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@KeySpace(KeyspaceConstants.PLAN_ADMINSTRATOR)
public class PlanAdminstrator extends DomainId {

	private static final long serialVersionUID = 4685365534740856768L;

	private String planId;
	private String planSponsors;
	private String controlledGroupName;
	private boolean planPublicallyTraded;
	private String classification;
	private String businessTaxCode;
	private String sponsorIdentification;
	private String planEntity;
	

}
