package com.genesis.core.domain.plan.domain.enums;

public enum PlanTypeDescription {
	
	NOT_APPLICABLE("0"),
	ESPO_401K("1"),
	ESPO_MONEY_PURCHASE("2"),
	ESPO_PROFIT_SHARING("3"),
	INHERITED_ROTH_IRA("19"),
	PUERTO_RICO("23");
	
	private String p3Code;
	
	PlanTypeDescription(String p3Code){
		this.p3Code = p3Code;
	}
	
	public String getP3code() {
		return this.p3Code;
	}

}
