package com.genesis.core.domain.plan.domain.enums;

public enum IRSBusinessTaxCode {
	
	OILSEED_GRAIN_FARMING(111100),
	VEGITABLE_MELON_FARMING(111200),
	FRUIT_TREE_NUT_FARMING(111300),
	GREENHOUSE_NURSERY(111400);
	
	private int p3Code;
	
	IRSBusinessTaxCode(int p3Code){
		this.p3Code = p3Code;
	}
	
	public int getP3code() {
		return this.p3Code;
	}

}
