package com.genesis.core.domain.plan.domain.enums;

public enum BreakPeriodOfService {
		
	ALL_PRIOR_SERVICE_CONTINUED(1),
	YEAR_BREAK_RULE_5_1(2),
	RULE_OF_PARITY(3), 
	NO_SERVICE_CONTINUED(4),
	OTHER(5);

	private Integer p3Code;

	BreakPeriodOfService(Integer p3Code) {
		this.p3Code = p3Code;
	}

	public Integer getP3Code() {
		return p3Code;
	}



}
