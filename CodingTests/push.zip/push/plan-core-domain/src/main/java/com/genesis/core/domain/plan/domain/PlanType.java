package com.genesis.core.domain.plan.domain;



import org.springframework.data.keyvalue.annotation.KeySpace;

import com.genesis.core.domain.framework.domain.DomainId;
import com.genesis.core.domain.framework.utils.KeyspaceConstants;
import com.genesis.core.domain.plan.domain.enums.ApplyPlanLevelDisclosures;
import com.genesis.core.domain.plan.domain.enums.DocumentType;
import com.genesis.core.domain.plan.domain.enums.EProspectusCode;
import com.genesis.core.domain.plan.domain.enums.PlanTypeCode;
import com.genesis.core.domain.plan.domain.enums.PlanTypeDescription;
import com.genesis.core.domain.plan.domain.enums.PriorCarrier;
import com.genesis.core.domain.plan.domain.enums.PriorCarrierPlantype;
import com.genesis.core.domain.plan.domain.enums.RothPlan;
import com.genesis.core.domain.plan.domain.enums.Segmentation;
import com.genesis.core.domain.plan.domain.enums.VoluntaryCode;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@KeySpace(KeyspaceConstants.PLAN_TYPE)
public class PlanType extends DomainId {
	
	private static final long serialVersionUID = -1034343778140237708L;
	private String planId;
	private Boolean isSoleCarrier;
	private Boolean isComparabilityPlan;
	private Boolean isPcraRemitAccount;
	private Boolean isAgeWeightedPlan;
	private Boolean isApplyParticipantFeeDisclosure;
	private Boolean isInvestmentReporting;
	private Boolean isEmployerStockCostBasisBySource;
	private Boolean isMigrated;
	private EProspectusCode eProspectusCode;
	private Boolean isParticipantInvestmentMaterialOverride;
	private Double interestRate;
	private Boolean isClarkOneAlignment;
	private PriorCarrier priorCarrier;
	private DocumentType documentType;
	private VoluntaryCode voluntaryCode;
	private PlanTypeCode planType;
	private PlanTypeDescription planTypeDescription;
	private Boolean isBrokerageSelectSDA;
	private Boolean isTotalRetirementOutsourcing;
	private Boolean isAllowServiceOnlyFunds;
	private PriorCarrierPlantype priorCarrierPlantype;
	private Segmentation segmentation;
	private String plan;
	private Boolean isErisaLoanRateAllowed;
	private Boolean erisaPlan;
	private RothPlan rothPlan;
	private Boolean isInPlanRothconversionsAllowed;
	private String mortalityTable;
	private ApplyPlanLevelDisclosures applyPlanLevelDisclosures;
	private String employerId;
	private String clientId;
	
	public PlanType(String id, String planId, Boolean isSoleCarrier, Boolean isComparabilityPlan, Boolean isPcraRemitAccount,
			Boolean isAgeWeightedPlan, Boolean isApplyParticipantFeeDisclosure, Boolean isInvestmentReporting,
			Boolean isEmployerStockCostBasisBySource, Boolean isMigrated, EProspectusCode eProspectusCode,
			Boolean isParticipantInvestmentMaterialOverride, Double interestRate, Boolean isClarkOneAlignment,
			PriorCarrier priorCarrier, DocumentType documentType, VoluntaryCode voluntaryCode, PlanTypeCode planType,
			PlanTypeDescription planTypeDescription, Boolean isBrokerageSelectSDA, Boolean isTotalRetirementOutsourcing,
			Boolean isAllowServiceOnlyFunds, PriorCarrierPlantype priorCarrierPlantype, Segmentation segmentation,
			String plan, Boolean isErisaLoanRateAllowed, Boolean erisaPlan, RothPlan rothPlan,
			Boolean isInPlanRothconversionsAllowed, String mortalityTable,
			ApplyPlanLevelDisclosures applyPlanLevelDisclosures, String employerId, String clientId) {
		
		super(id);
		this.planId = planId;
		this.isSoleCarrier = isSoleCarrier;
		this.isComparabilityPlan = isComparabilityPlan;
		this.isPcraRemitAccount = isPcraRemitAccount;
		this.isAgeWeightedPlan = isAgeWeightedPlan;
		this.isApplyParticipantFeeDisclosure = isApplyParticipantFeeDisclosure;
		this.isInvestmentReporting = isInvestmentReporting;
		this.isEmployerStockCostBasisBySource = isEmployerStockCostBasisBySource;
		this.isMigrated = isMigrated;
		this.eProspectusCode = eProspectusCode;
		this.isParticipantInvestmentMaterialOverride = isParticipantInvestmentMaterialOverride;
		this.interestRate = interestRate;
		this.isClarkOneAlignment = isClarkOneAlignment;
		this.priorCarrier = priorCarrier;
		this.documentType = documentType;
		this.voluntaryCode = voluntaryCode;
		this.planType = planType;
		this.planTypeDescription = planTypeDescription;
		this.isBrokerageSelectSDA = isBrokerageSelectSDA;
		this.isTotalRetirementOutsourcing = isTotalRetirementOutsourcing;
		this.isAllowServiceOnlyFunds = isAllowServiceOnlyFunds;
		this.priorCarrierPlantype = priorCarrierPlantype;
		this.segmentation = segmentation;
		this.plan = plan;
		this.isErisaLoanRateAllowed = isErisaLoanRateAllowed;
		this.erisaPlan = erisaPlan;
		this.rothPlan = rothPlan;
		this.isInPlanRothconversionsAllowed = isInPlanRothconversionsAllowed;
		this.mortalityTable = mortalityTable;
		this.applyPlanLevelDisclosures = applyPlanLevelDisclosures;
		this.employerId = employerId;
		this.clientId = clientId;
	}


	
}
