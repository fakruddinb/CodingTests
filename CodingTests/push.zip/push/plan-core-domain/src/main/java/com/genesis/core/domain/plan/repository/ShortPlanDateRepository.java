package com.genesis.core.domain.plan.repository;



import org.springframework.data.repository.CrudRepository;

import com.genesis.core.domain.plan.domain.ShortPlanDate;

public interface ShortPlanDateRepository extends CrudRepository<ShortPlanDate, String> {
	
   

}
