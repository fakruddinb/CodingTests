package com.genesis.core.domain.plan.domain;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class PlanAppModel implements Serializable {

	private static final long serialVersionUID = 5577938562939109466L;
	private String lineOfBusiness;
	private String defaultGroupCode;
	private String planName;
	private long enrlProvGrpId;
	private String planType;
	private boolean rothPlan;
	private double totalAccountBalance;
	
	private List<PlanSourceAppModel> sources;
}
