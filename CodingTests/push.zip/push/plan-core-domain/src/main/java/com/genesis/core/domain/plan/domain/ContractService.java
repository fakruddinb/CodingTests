package com.genesis.core.domain.plan.domain;



import org.springframework.data.keyvalue.annotation.KeySpace;

import com.genesis.core.domain.framework.domain.DomainId;
import com.genesis.core.domain.framework.utils.KeyspaceConstants;
import com.genesis.core.domain.plan.domain.enums.ContractIssuer;
import com.genesis.core.domain.plan.domain.enums.EmployerType;
import com.genesis.core.domain.plan.domain.enums.FundFamily;
import com.genesis.core.domain.plan.domain.enums.PaaPricingMethod;
import com.genesis.core.domain.plan.domain.enums.PaaType;
import com.genesis.core.domain.plan.domain.enums.ServiceType;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@KeySpace(KeyspaceConstants.CONTRACT_SERVICE)
public class ContractService extends DomainId {

	private static final long serialVersionUID = -3760879573583560709L;
	private String planId;
	private ContractIssuer contractIssuer;
	private FundFamily fundFamily;
	private ServiceType serviceType;
	private EmployerType employerType;
	private PaaType paaType;
	private PaaPricingMethod paaPricingMethod;
	
	public ContractService(String id, String planId, ContractIssuer contractIssuer, FundFamily fundFamily, ServiceType serviceType,
			EmployerType employerType, PaaType paaType, PaaPricingMethod paaPricingMethod) {
		super(id);
		this.planId = planId;
		this.contractIssuer = contractIssuer;
		this.fundFamily = fundFamily;
		this.serviceType = serviceType;
		this.employerType = employerType;
		this.paaType = paaType;
		this.paaPricingMethod = paaPricingMethod;
	}
	
   

}
