package com.genesis.core.domain.plan.repository;

import java.util.List;


import org.springframework.data.repository.CrudRepository;

import com.genesis.core.domain.plan.domain.PlanSource;

public interface PlanSourceRepository extends CrudRepository<PlanSource, String> {
	
   
	List<PlanSource> findByPlanId(String planId);
}
