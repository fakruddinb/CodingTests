package com.genesis.core.domain.plan.domain;



import org.springframework.data.keyvalue.annotation.KeySpace;

import com.genesis.core.domain.framework.domain.DomainId;
import com.genesis.core.domain.framework.utils.KeyspaceConstants;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@KeySpace(KeyspaceConstants.FORMULA_OPTION)
public class FormulaOption extends DomainId {

	private static final long serialVersionUID = -1387240855460352315L;
	private String planSourceId;
	private String formulaC;
	private String integratedLvLCd;
	private String integratedLvLCdDesc;
	private String formulaT;
	private Double sourceMaxP;
	private Double sourceMinP;
	private Double sourceMinA;
	private Double bkptXValP;
	
	public FormulaOption(String id, String planSourceId, String formulaC, String integratedLvLCd, String integratedLvLCdDesc,
			String formulaT, Double sourceMaxP, Double sourceMinP, Double sourceMinA, Double bkptXValP) {
		super(id);
		this.planSourceId = planSourceId;
		this.formulaC = formulaC;
		this.integratedLvLCd = integratedLvLCd;
		this.integratedLvLCdDesc = integratedLvLCdDesc;
		this.formulaT = formulaT;
		this.sourceMaxP = sourceMaxP;
		this.sourceMinP = sourceMinP;
		this.sourceMinA = sourceMinA;
		this.bkptXValP = bkptXValP;
	}

}
