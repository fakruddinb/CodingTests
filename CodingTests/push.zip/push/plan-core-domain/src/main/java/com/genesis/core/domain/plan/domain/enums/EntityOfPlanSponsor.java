package com.genesis.core.domain.plan.domain.enums;

public enum EntityOfPlanSponsor {
	
	SINGLE_EMPLOYER(1),
	CONTROLEED_GROUP_EMPLOER(2),
	SEPERATE_LINE_OF_BUSINESS(3),
	AFFLIATED_SERVICE_GROUPS(4);
	
	private int p3Code;
	
	EntityOfPlanSponsor(int p3Code){
		this.p3Code = p3Code;
	}
	
	public int getP3code() {
		return this.p3Code;
	}
}
