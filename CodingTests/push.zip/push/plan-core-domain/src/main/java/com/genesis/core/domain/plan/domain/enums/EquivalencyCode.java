package com.genesis.core.domain.plan.domain.enums;

public enum EquivalencyCode {
	
	WEEK_45_HOURS(1),
	SEMI_MONTH_95_HOURS(2),
	MONTH_190_HOURS(3), 
	X_PERIOD_X_HOURS(4),
	DAY_10_HOURS(5);

	private Integer p3Code;

	EquivalencyCode(Integer p3Code) {
		this.p3Code = p3Code;
	}

	public Integer getP3Code() {
		return p3Code;
	}

}
