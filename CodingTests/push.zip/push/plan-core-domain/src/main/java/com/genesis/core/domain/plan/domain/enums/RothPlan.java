package com.genesis.core.domain.plan.domain.enums;

public enum RothPlan {
	
	NO('0'),
	ROTH_401K('N'),
	ROTH_403B('Z');
	
	private char p3Code;
	
	RothPlan(char p3Code){
		this.p3Code = p3Code;
	}
	
	public char getP3code() {
		return this.p3Code;
	}

}
