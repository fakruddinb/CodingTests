package com.genesis.core.domain.plan.domain.enums;

public enum ApplyPlanLevelDisclosures {
	
	NO_DISCLOSURES(0),
	INITIAL_DISCLOSURES(1),
	CHANGE_DISCLOSURES(3);
	
	private int p3Code;
	
	ApplyPlanLevelDisclosures(int p3Code){
		this.p3Code = p3Code;
	}
	
	public int getP3code() {
		return this.p3Code;
	}

}
