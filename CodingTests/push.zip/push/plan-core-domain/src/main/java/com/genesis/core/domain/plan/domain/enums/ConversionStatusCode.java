package com.genesis.core.domain.plan.domain.enums;

public enum ConversionStatusCode {
	
	PENDING_NO_ACTIVITY(1),
	PENDING_ENROLLMENTS_ONLY(20),
	IN_CANCELLATION(4),
	CALNCELLED(5),
	ACTIVE(7),
	INACTIVE(9),
	TERMINATED(12),
	PAID_OUT(13),
	CONVERTED(14);
	
	private Integer p3Code;
	
	ConversionStatusCode(Integer p3Code) {
		this.p3Code = p3Code;
	}

	public Integer getP3Code() {
		return p3Code;
	}

}
