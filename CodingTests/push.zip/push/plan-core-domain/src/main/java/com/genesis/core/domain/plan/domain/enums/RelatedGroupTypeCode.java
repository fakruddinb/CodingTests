package com.genesis.core.domain.plan.domain.enums;

public enum RelatedGroupTypeCode {
	
	CARVE_OUT_GROUP(361),
	PROVISION_GROUP(362);
	
	private int typeCode;
	
	RelatedGroupTypeCode(int typeCode) {
		this.typeCode = typeCode;
	}
	
	public int getTypeCode() {
		return this.typeCode;
	}
}
