package com.genesis.core.domain.plan.repository;



import org.springframework.data.repository.CrudRepository;

import com.genesis.core.domain.plan.domain.PlanProvisions;

public interface PlanProvisionRepository extends CrudRepository<PlanProvisions, String> {
	
   

}
