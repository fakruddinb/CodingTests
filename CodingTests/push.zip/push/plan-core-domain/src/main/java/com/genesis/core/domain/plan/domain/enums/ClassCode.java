package com.genesis.core.domain.plan.domain.enums;

public enum ClassCode {
	
	ALL(0), 
	CLASSEE(1),
	LBLWR(2),
	TEMP(3), 
	HOURLY(4),
	INDCON(5);

	private Integer p3Code;

	ClassCode(Integer p3Code) {
		this.p3Code = p3Code;
	}

	public Integer getP3Code() {
		return p3Code;
	}

}
