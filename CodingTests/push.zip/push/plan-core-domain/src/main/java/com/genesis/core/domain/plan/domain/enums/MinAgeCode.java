package com.genesis.core.domain.plan.domain.enums;

public enum MinAgeCode {
	
	NO_AGE(0),
	AGE_21(1),
	AGE_20(2),
	AGE_19(3), 
	AGE_18(4),
	AGE_17(5);

	private Integer p3Code;

	MinAgeCode(Integer p3Code) {
		this.p3Code = p3Code;
	}

	public Integer getP3Code() {
		return p3Code;
	}

}
