package com.genesis.core.domain.plan.repository;

import java.util.List;


import org.springframework.data.repository.CrudRepository;

import com.genesis.core.domain.plan.domain.PlanFund;

public interface PlanFundRepository extends CrudRepository<PlanFund, String> {
	
	List<PlanFund> findByPlanId(String planId);

}
