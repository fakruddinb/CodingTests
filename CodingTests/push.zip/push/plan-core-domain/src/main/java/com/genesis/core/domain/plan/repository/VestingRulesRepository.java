package com.genesis.core.domain.plan.repository;



import org.springframework.data.repository.CrudRepository;

import com.genesis.core.domain.plan.domain.VestingRules;

public interface VestingRulesRepository extends CrudRepository<VestingRules, String> {
	
   

}
