package com.genesis.core.domain.plan.repository;



import org.springframework.data.repository.CrudRepository;

import com.genesis.core.domain.plan.domain.Sponsor;

public interface SponsorRepository extends CrudRepository<Sponsor, String> {
	
   

}
