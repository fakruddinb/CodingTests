package com.genesis.core.domain.plan.domain.enums;

public enum PeriodsofServiceMeans {
	
	NA(0),
	ELIGIBILITY(1),
	VESTING(2);
	
	private int p3Code;
	
	PeriodsofServiceMeans(int p3Code){
		this.p3Code = p3Code;
	}
	
	public int getP3code() {
		return this.p3Code;
	}

}
