package com.genesis.core.domain.plan.domain.enums;

public enum CalculationOfContribution {
	
	OTHER(0), 
	WEEKLY(1),
	BI_WEEKLY(2), 
	SEMI_MONTHLY(3),
	QUARTERLY(4), 
	PAYROLL_BASIS(6),
	ANNUAL(7), 
	MONTHLY(8);

	private Integer p3Code;

	CalculationOfContribution(Integer p3Code) {
		this.p3Code = p3Code;
	}

	public Integer getP3Code() {
		return p3Code;
	}

}
