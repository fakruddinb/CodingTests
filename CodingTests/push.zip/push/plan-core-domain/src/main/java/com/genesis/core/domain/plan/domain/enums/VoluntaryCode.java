package com.genesis.core.domain.plan.domain.enums;

public enum VoluntaryCode {
	
	NOT_APPLICABLE(0),
	VOLUNTARY(1),
	INSTITUTIONAL(2),
	INSTITUTIONAL_CORP(3);
	
	private int p3Code;
	
	VoluntaryCode(int p3Code){
		this.p3Code = p3Code;
	}
	
	public int getP3code() {
		return this.p3Code;
	}

}
