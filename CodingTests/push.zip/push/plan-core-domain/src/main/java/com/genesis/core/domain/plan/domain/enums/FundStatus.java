package com.genesis.core.domain.plan.domain.enums;

public enum FundStatus {
	
	ACTIVE(0),
	INACTIVE(1),
	PENDING(2),
	ACTIVE_NOT_FOR_COG(3);
	
	private int statusCode;
	
	FundStatus(int statusCode) {
		this.statusCode = statusCode;
	}
	
	public int getStatusCode() {
		return this.statusCode;
	}

}
