package com.genesis.core.domain.plan.domain.enums;

public enum EACAIndicatorCode {
	
	EACA(1), 
	ACA(2),
	QACA(3);

	private Integer p3Code;

	EACAIndicatorCode(Integer p3Code) {
		this.p3Code = p3Code;
	}
	public Integer getP3Code() {
		return p3Code;
	}

}
