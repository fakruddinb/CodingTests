package com.genesis.core.domain.plan.domain;



import org.springframework.data.keyvalue.annotation.KeySpace;

import com.genesis.core.domain.framework.domain.DomainId;
import com.genesis.core.domain.framework.utils.KeyspaceConstants;
import com.genesis.core.domain.plan.domain.enums.CalculationOfContribution;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@KeySpace(KeyspaceConstants.CALCULATION_INFORMATION)
public class CalculationInformation extends DomainId {
	
	private static final long serialVersionUID = -4536405693844332935L;
	private String planSourceId;
	private CalculationOfContribution calculationOfContribution;
	private String ctrbCalcDescT;
	private Boolean isAannualMatchCode;
	private Boolean isMatchIncludedTrueUpCalCode;
	private Boolean isConditionedOnProfitCode;
	private Boolean isCombinedDeferralsCode;
	private Integer catchupMatchContribution;
	
	public CalculationInformation(String id, String planSourceId, CalculationOfContribution calculationOfContribution,
			String ctrbCalcDescT, Boolean isAannualMatchCode, Boolean isMatchIncludedTrueUpCalCode,
			Boolean isConditionedOnProfitCode, Boolean isCombinedDeferralsCode, Integer catchupMatchContribution) {
		super(id);
		this.planSourceId = planSourceId;
		this.calculationOfContribution = calculationOfContribution;
		this.ctrbCalcDescT = ctrbCalcDescT;
		this.isAannualMatchCode = isAannualMatchCode;
		this.isMatchIncludedTrueUpCalCode = isMatchIncludedTrueUpCalCode;
		this.isConditionedOnProfitCode = isConditionedOnProfitCode;
		this.isCombinedDeferralsCode = isCombinedDeferralsCode;
		this.catchupMatchContribution = catchupMatchContribution;
	}
	
}
