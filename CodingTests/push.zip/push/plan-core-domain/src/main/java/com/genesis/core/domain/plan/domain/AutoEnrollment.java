package com.genesis.core.domain.plan.domain;

import java.time.LocalDate;


import org.springframework.data.keyvalue.annotation.KeySpace;

import com.genesis.core.domain.framework.domain.DomainId;
import com.genesis.core.domain.framework.utils.KeyspaceConstants;
import com.genesis.core.domain.plan.domain.enums.AutoEsclateIncreseCode;
import com.genesis.core.domain.plan.domain.enums.EACAIndicatorCode;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@KeySpace(KeyspaceConstants.AUTO_ENROLLMENT)
public class AutoEnrollment extends DomainId {

	
	static final long serialVersionUID = 7185534441591862684L;

	private String planSourceId;
	private LocalDate autoEnrleffectiveDate;
	private Boolean isSixMonthRefundCode;
	private EACAIndicatorCode eacaIndicatorCode;
	private LocalDate eacaEffectiveDate;
	private Boolean isAutoEscalateFeatureCode;
	private String autoEscltP;
	private AutoEsclateIncreseCode autoEsclateIncreseCode;
	private String autoEscltMMDD;
	private LocalDate autoEscltEffDate;
	
	public AutoEnrollment(String id, String planSourceId, LocalDate autoEnrleffectiveDate, Boolean isSixMonthRefundCode,
			EACAIndicatorCode eacaIndicatorCode, LocalDate eacaEffectiveDate, Boolean isAutoEscalateFeatureCode,
			String autoEscltP, AutoEsclateIncreseCode autoEsclateIncreseCode, String autoEscltMMDD,
			LocalDate autoEscltEffDate) {
		super(id);
		this.planSourceId = planSourceId;
		this.autoEnrleffectiveDate = autoEnrleffectiveDate;
		this.isSixMonthRefundCode = isSixMonthRefundCode;
		this.eacaIndicatorCode = eacaIndicatorCode;
		this.eacaEffectiveDate = eacaEffectiveDate;
		this.isAutoEscalateFeatureCode = isAutoEscalateFeatureCode;
		this.autoEscltP = autoEscltP;
		this.autoEsclateIncreseCode = autoEsclateIncreseCode;
		this.autoEscltMMDD = autoEscltMMDD;
		this.autoEscltEffDate = autoEscltEffDate;
	}
	
	

}
