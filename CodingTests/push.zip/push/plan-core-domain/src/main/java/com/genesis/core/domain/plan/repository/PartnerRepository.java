package com.genesis.core.domain.plan.repository;



import org.springframework.data.repository.CrudRepository;

import com.genesis.core.domain.plan.domain.Partner;

public interface PartnerRepository extends CrudRepository<Partner, String> {
	
   

}
