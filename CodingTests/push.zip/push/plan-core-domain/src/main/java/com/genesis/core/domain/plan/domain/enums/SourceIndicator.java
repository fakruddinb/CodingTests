package com.genesis.core.domain.plan.domain.enums;

public enum SourceIndicator {
	
	FROZEN('F'), 
	ACTIVE('A'),
	SUSPENSE('S');

	private char p3Code;
	
	SourceIndicator(char p3Code){
		this.p3Code = p3Code;
	}
	
	public char getP3code() {
		return this.p3Code;
	}

}
