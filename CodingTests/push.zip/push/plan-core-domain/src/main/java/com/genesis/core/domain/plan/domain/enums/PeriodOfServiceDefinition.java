package com.genesis.core.domain.plan.domain.enums;

public enum PeriodOfServiceDefinition {
	
	HOURS(1),
	ELAPSED(2);
	
	private int p3Code;
	
	PeriodOfServiceDefinition(int p3Code){
		this.p3Code = p3Code;
	}
	
	public int getP3code() {
		return this.p3Code;
	}

}
