package com.genesis.core.domain.plan.domain.enums;

public enum EmployerType {
	
	SEP(1),
	PAA(2);
	
	private int p3Code;
	
	EmployerType(int p3Code){
		this.p3Code = p3Code;
	}
	
	public int getP3code() {
		return this.p3Code;
	}

}
