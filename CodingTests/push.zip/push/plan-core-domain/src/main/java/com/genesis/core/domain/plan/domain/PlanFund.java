package com.genesis.core.domain.plan.domain;

import java.time.LocalDate;


import org.springframework.data.keyvalue.annotation.KeySpace;

import com.genesis.core.domain.framework.domain.DomainId;
import com.genesis.core.domain.framework.utils.KeyspaceConstants;
import com.genesis.core.domain.plan.domain.enums.DisplayCode;
import com.genesis.core.domain.plan.domain.enums.FundDescCode;
import com.genesis.core.domain.plan.domain.enums.FundStatus;
import com.genesis.core.domain.plan.domain.enums.RemitActionCode;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@KeySpace(KeyspaceConstants.PLAN_FUND)
public class PlanFund extends DomainId {

	private static final long serialVersionUID = -1563569888762060558L;
	private String planId;
	private Long provisionId;
	private String reportFundName;
	private FundDescCode fundDescCode;
	private Integer fundSequanceNo;
	private LocalDate effectiveDate;
	private LocalDate closeDate;
	private LocalDate reactivationDate;
	private FundStatus fundStatus;
	private RemitActionCode remitActionCode;
	private DisplayCode displayCode;
	
	public PlanFund(String id, String planId, Long provisionId, String reportFundName, FundDescCode fundDescCode,
			Integer fundSequanceNo, LocalDate effectiveDate, LocalDate closeDate, LocalDate reactivationDate,
			FundStatus fundStatus, RemitActionCode remitActionCode, DisplayCode displayCode) {
		super(id);
		this.planId = planId;
		this.provisionId = provisionId;
		this.reportFundName = reportFundName;
		this.fundDescCode = fundDescCode;
		this.fundSequanceNo = fundSequanceNo;
		this.effectiveDate = effectiveDate;
		this.closeDate = closeDate;
		this.reactivationDate = reactivationDate;
		this.fundStatus = fundStatus;
		this.remitActionCode = remitActionCode;
		this.displayCode = displayCode;
	}


	
}
