package com.genesis.core.domain.plan.domain.enums;

public enum FundFamily {
	
	BAML(7),
	NAV_PLANS(8),
	TLIC_PLANS(12),
	TFLIC_PLANS(13);
	
	private int p3Code;
	
	FundFamily(int p3Code){
		this.p3Code = p3Code;
	}
	
	public int getP3code() {
		return this.p3Code;
	}
	

}
