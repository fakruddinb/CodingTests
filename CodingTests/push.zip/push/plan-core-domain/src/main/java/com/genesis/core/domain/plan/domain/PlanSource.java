package com.genesis.core.domain.plan.domain;

import java.time.LocalDate;


import org.springframework.data.keyvalue.annotation.KeySpace;

import com.genesis.core.domain.framework.domain.DomainId;
import com.genesis.core.domain.framework.utils.KeyspaceConstants;
import com.genesis.core.domain.plan.domain.enums.InvestmentDirection;
import com.genesis.core.domain.plan.domain.enums.SourceIndicator;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@KeySpace(KeyspaceConstants.PLAN_SOURCE)
public class PlanSource extends DomainId {

	private static final long serialVersionUID = -4653963071839692698L;
	private String planId;
	private Long provisionId;
	private Long sourceId;
	private String documentName;
	private String sourceType;
	private String translationName;
	private Integer sequenceNumber;
	private SourceIndicator sourceIndicator;
	private InvestmentDirection investmentDirection;
	private Boolean isPpaSafeHarbor;
	private LocalDate ppaQacaEffectiveDate;
	private Boolean isAnnualSafeHarborNoticeMailed;
	private String reportSourceName;
	private String safeHarborMatchContribution;
	private String autoEnrollmentcode;

}